//
//  main.m
//  SkyrcGPS
//
//  Created by wsj on 2018/11/21.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
