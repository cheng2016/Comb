//
//  NEUtilityConstance.h
//  RevogiHome
//
//  Created by NEIL on 2017/6/27.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#ifndef NEUtilityConstance_h
#define NEUtilityConstance_h

#import <UIKit/UIKit.h>

typedef void(^onClickeButtonHander)(id) ;

#define toRadians(x) (M_PI*(x)/180.0) //把角度转换成PI的方式

#pragma mark - Localization String
#define NEString(key) [[NELanguage sharedManager] getLocalizedString:key]

#pragma mark - NEError
#define kNEError(msg, code) [NSError errorWithDomain:msg code:code userInfo:nil]

#define UIColorFromRGB(rgbValue) \
[UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define UIColorWith256RGB(r, g, b) UIColorWith256ARGB(1.0f, r, g, b)
#define UIColorWith256ARGB(a, r, g, b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define UIColorWithRGB(r, g, b) UIColorWithARGB(1.0f, r, g, b)
#define UIColorWithARGB(a, r, g, b) [UIColor colorWithRed:r green:g blue:b alpha:a]

#define kNEColorBlackGray    UIColorWith256RGB(46, 46, 46)

#define kNEColorBlue        UIColorWith256RGB(0, 208, 255)
#define kNEColorGreen       UIColorWith256RGB(36, 246, 53)
#define kNEColorRed         UIColorWith256RGB(251, 84, 6)

#define KNEColorPurple      UIColorWith256RGB(192, 0, 255)
#define kNEColorWhite       UIColorWith256RGB(254, 254, 254)
#define kNEColorOrange      UIColorWith256RGB(255, 133, 5)
#define kNEColorBlack       UIColorWith256RGB(0, 0, 0)
#define kNEColorBlackLight  [kNEColorBlack colorWithAlphaComponent:0.1f]


#define kNEColorHighlighted    UIColorWith256RGB(138, 138, 138)
#define kNEColorLine        UIColorFromRGB(0X2e2e2e)

#pragma mark - iOS Font Name

#define kNECustomFontName @"Helvetica"

#define kNECustomBoldFontName @"HelveticaNeue-Bold"

#define kNEFont(x) [NEUtility systemFontOfSize:x]

#if (TARGET_OS_SIMULATOR)
#define isSimulator 1
#else
#define isSimulator 0
#endif

#pragma mark - iOS Model Size

#define statusBar_Height [[UIApplication sharedApplication] statusBarFrame].size.height
#define scrWidth    ([[UIScreen mainScreen] bounds].size.width)
#define scrHeight   ([[UIScreen mainScreen] bounds].size.height)

#define iPad    [[UIDevice currentDevice].model isEqualToString:@"iPad"]
#define iPhone  [[UIDevice currentDevice].model isEqualToString:@"iPhone"]
#define iPod    [[UIDevice currentDevice].model isEqualToString:@"iPod touch"]
#define iPhone4 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960) , [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6Plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242,2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125,2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhoneXR ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828,1792), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhoneXS_MAX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242,2688), [[UIScreen mainScreen] currentMode].size) : NO)

#define IS_IPhoneX_All (statusBar_Height > 20 ? YES:NO)

#pragma mark - UIImage Load

#define UIImageNamed(name)  [UIImage imageNamed:name]
#define UIImageData(data)   [UIImage imageWithData:data]
#define ResourcePath(path)  [[NSBundle mainBundle] pathForResource:path ofType:nil] 
#define UIImagePath(path)   [UIImage imageWithContentsOfFile:ResourcePath(path)]


#pragma mark - NELog

#ifdef DEBUG

#define NELogHead [NSString stringWithFormat:@"-- %@:%d -",[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] stringByDeletingPathExtension],__LINE__]

#define NELog(FORMAT, ...) \
fprintf(stderr,"[%-40.40s] %s\n",[[NELogHead stringByAppendingString:@"------------------------------"]UTF8String],[[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);

#else

#define NELog(FORMAT, ...) [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String];

#endif //DEBUG

#endif
