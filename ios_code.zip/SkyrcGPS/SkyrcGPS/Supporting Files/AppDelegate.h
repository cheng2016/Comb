//
//  AppDelegate.h
//  SkyrcGPS
//
//  Created by wsj on 2018/11/21.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

