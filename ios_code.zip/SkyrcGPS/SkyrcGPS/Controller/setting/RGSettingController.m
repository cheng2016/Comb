//
//  RGSettingController.m
//  SkyrcGPS
//
//  Created by wsj on 2018/11/21.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import "RGSettingController.h"
#import "RGSearchBluView.h"

#define KHistoricalKey  @"Historical_achievements"
#define KUnitKey        @"Unit_switching"
#define KFirmwareKey    @"Firmware_version"
#define KDeviceCacheKey @"Clear_device_cache"


@interface RGSettingController ()

@property (nonatomic, strong) RGSearchBluView *searchBluView;
//@property (nonatomic, strong) RGSearchBluView *alertView;
@property (nonatomic, strong) NEBluetoothManager *blutoothManger;

@property (weak, nonatomic) IBOutlet UITextField *modelText;
@property (weak, nonatomic) IBOutlet UITextField *repeatText;

@property (weak, nonatomic) IBOutlet UITextField *IRText;
@property (weak, nonatomic) IBOutlet UITextField *IRTimeText;
@property (weak, nonatomic) IBOutlet UITextField *REDText;
@property (weak, nonatomic) IBOutlet UITextField *REDTimeText;

@property (weak, nonatomic) IBOutlet UITextField *IRText2;
@property (weak, nonatomic) IBOutlet UITextField *IRTimeText2;
@property (weak, nonatomic) IBOutlet UITextField *REDText2;
@property (weak, nonatomic) IBOutlet UITextField *REDTimeText2;


@property (weak, nonatomic) IBOutlet UITextField *resultText;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;



@end

@implementation RGSettingController
- (IBAction)xiafaAction:(id)sender {
    unsigned char sendStr[105];
    sendStr[0] = 0X0F;
    sendStr[1] = 0X65;
    sendStr[2] = 0X01;
    sendStr[3] = 0X00;
    sendStr[4] = [self.modelText.text integerValue];
    sendStr[5] = [self.repeatText.text integerValue];
    sendStr[6] = [self.IRText.text integerValue];
    sendStr[7] = [self.IRTimeText.text integerValue]>>8%0X100;
    sendStr[8] = [self.IRTimeText.text integerValue]%0X100;
    sendStr[9] = [self.REDText.text integerValue];
    sendStr[10] = [self.REDTimeText.text integerValue]>>8%0X100;
    sendStr[11] = [self.REDTimeText.text integerValue]%0X100;
    
    sendStr[12] = [self.IRText2.text integerValue];
    sendStr[13] = [self.IRTimeText2.text integerValue]>>8%0X100;
    sendStr[14] = [self.IRTimeText2.text integerValue]%0X100;
    sendStr[15] = [self.REDText2.text integerValue];
    sendStr[16] = [self.REDTimeText2.text integerValue]>>8%0X100;
    sendStr[17] = [self.REDTimeText2.text integerValue]%0X100;
    
    for (NSInteger i = 1; i <= 14; i++) {
        sendStr[12 + i * 6] = 10;
        sendStr[13 + i * 6] = 0;
        sendStr[14 + i * 6] = 10;
        sendStr[15 + i * 6] = 10;
        sendStr[16 + i * 6] = 0;
        sendStr[17 + i * 6] = 10;
    }
    
    sendStr[102] = 0X00;
    sendStr[103] = 0XFF;
    sendStr[104] = 0XFF;
    
    NSData *writeData = [[NEBluetoothManager sharedManager] CheckSum:sendStr length:105];
    NSData *writeData1 = [writeData subdataWithRange:NSMakeRange(0, 60)];
    NSData *writeData2 = [writeData subdataWithRange:NSMakeRange(60, 45)];
    [[NEBluetoothManager sharedManager] testTime:writeData1];
    [[NEBluetoothManager sharedManager] testTime:writeData2];
}
- (IBAction)selectAction:(id)sender {
    [[NEBluetoothManager sharedManager] getResult:^(BluetoothCode code, id data) {
        self.resultLabel.text = data;
    } index:[self.modelText.text integerValue]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.blutoothManger = [NEBluetoothManager sharedManager];
    WEAKSELF
    self.blutoothManger.connectResultBlock = ^(BluetoothCode code, id data) {
        [weakself dismissLoadingDialog:YES];
        if (code ==  BluetoothCodeTyppCorrent) {
            weakself.title = RGConnectDevice.name;
        }
    };
    
}
-(RGSearchBluView *)searchBluView
{
    if (!_searchBluView) {
        _searchBluView =[[[NSBundle mainBundle] loadNibNamed:@"RGSearchBluView" owner:self options:nil] firstObject];
        _searchBluView.bounds = CGRectMake(0, 0, scrWidth - 80, scrHeight - 400);
    }
    return _searchBluView;
}
- (IBAction)addDevice:(id)sender {
    if (RGConnectDevice.isOnline) {
        [[NEBluetoothManager sharedManager] disconnect:RGConnectDevice.devicePeripheral];
    }
    if (self.blutoothManger.isBluetoothEnable) {
        [self.searchBluView showView];
    }
    
}


@end
