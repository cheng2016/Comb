//
//  RGHDOPView.h
//  SkyrcGPS
//
//  Created by wsj on 2018/12/3.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RGHDOPView : UIView

@property (nonatomic, assign) CGFloat HDOP;

@end

NS_ASSUME_NONNULL_END
