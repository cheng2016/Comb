//
//  RGSearchBluView.m
//  SkyrcGPS
//
//  Created by wsj on 2018/11/21.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import "RGSearchBluView.h"
@interface RGSearchBluView ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) MBProgressHUD *loadingHUD;

@property (weak, nonatomic) IBOutlet UILabel *titleView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;


@property (nonatomic, strong) NEBluetoothManager *blutoothManger;
@property (weak, nonatomic) IBOutlet UILabel *signalLabel;


@end

@implementation RGSearchBluView

-(void)awakeFromNib
{
    [super awakeFromNib];
    self.backgroundColor = [UIColor whiteColor];
    self.blutoothManger = [NEBluetoothManager sharedManager];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [UIView new];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self viewDidLayoutSubviews];
}

-(void)didChangeLanguage
{
    self.titleView.text = NEString(@"select_device");
    [self.cancelBtn setTitle:NEString(@"cancel") forState:UIControlStateNormal];
}

- (void)reloadData
{
    CGFloat height = 49+44+RGAppManager.BluetoothListArray.count * 46;
    if (height < scrHeight - 400) {
        height = scrHeight - 400;
    }else if (height > scrHeight - 200) {
        height = scrHeight - 200;
    }
    self.bounds = CGRectMake(0, 0, self.frame.size.width, height);
    [self.tableView reloadData];
}

-(void)showView
{
    NEDialog *_dialog =  [NEDialog shareManager];
    _dialog.style = PopStyleDefault;
    [_dialog showDialog:self cmpt:nil];
    
    if (self.type == RGSearchTypeSearch) {
        [self didChangeLanguage];
        WEAKSELF
        [RGAppManager.BluetoothListArray removeAllObjects];
        [self.blutoothManger startscaningIsbackscandevice:YES viewcontroller:nil];
        [self reloadData];
        [self.blutoothManger setFindNewBluetoothBlock:^{
            [weakself reloadData];
        }];
    }else{
        self.tableView.hidden = YES;
        self.titleView.text = NEString(@"Tips");
        [self.cancelBtn setTitle:NEString(@"ok") forState:UIControlStateNormal];
        self.signalLabel.text = NEString(@"no_signal");
    }
}
-(void)dismissDialog
{
    NEDialog *_dialog =  [NEDialog shareManager];
    [_dialog dismissDialog:nil];
}
- (IBAction)cancelAction:(id)sender {
    [self dismissDialog];
    [self.blutoothManger stopScanning];
}




#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return RGAppManager.BluetoothListArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (RGAppManager.BluetoothListArray.count > indexPath.row) {
        RGDevice *device = RGAppManager.BluetoothListArray[indexPath.row];
        cell.textLabel.textColor = UIColorWith256RGB(76, 76, 76);
        cell.textLabel.text = device.name;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (!self.blutoothManger.isBluetoothEnable) {
        return;
    }
    if (RGAppManager.BluetoothListArray.count > indexPath.row) {
        RGDevice *device = RGAppManager.BluetoothListArray[indexPath.row];
        WEAKSELF
        [[NEBluetoothManager sharedManager] disconnect:RGConnectDevice.devicePeripheral];
        [self showLoadingDialog];
        [self.blutoothManger connectDevice:device result:^(BluetoothCode code, id data) {
            [weakself performSelector:@selector(dismissLoadingDialog) withObject:nil afterDelay:0.5];
        }];
    }
    
}

-(void)viewDidLayoutSubviews
{
    if ([self.tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.tableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    if ([self.tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.tableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

- (void)showLoadingDialog
{
    self.loadingHUD = [MBProgressHUD showHUDAddedTo:self animated:YES];
    self.loadingHUD.mode = MBProgressHUDModeIndeterminate;
    self.loadingHUD.bezelView.color = UIColorWithARGB(0.8f, 0.2f, 0.2f, 0.2f);
    self.loadingHUD.label.text = NEString(@"loading");
}
- (void)dismissLoadingDialog
{
    [self.loadingHUD hideAnimated:YES];
    if (RGAppManager.connectDevice.isOnline) {
        [self dismissDialog];
    }
}
@end
