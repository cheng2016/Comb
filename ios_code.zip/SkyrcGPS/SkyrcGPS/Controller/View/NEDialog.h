//
//  NEDialog.h
//  RevogiHome
//
//  Created by NEIL on 2017/2/8.
//  Copyright © 2017年 NEIL. All rights reserved.
//


//#import "NEBaseView.h"

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, PopStyle){
    PopStyleDefault = 0,//center
    PopStyleTop,
    PopStyleBottom,
};

@interface NEDialog : UIView

@property (nonatomic, assign) PopStyle style;

@property (nonatomic, assign, readonly) BOOL isShow;

@property (nonatomic, assign) float duration;

@property (nonatomic, assign) BOOL isCornerRadius;

@property (nonatomic, assign) BOOL isTouchHidden;

@property (nonatomic, weak) UIView *superView;


+ (NEDialog *)shareManager;

- (void)restoreDefault;

- (void)showDialog:(UIView *)dialogView cmpt:(void (^ )(void))cmpt;

- (void)dismissDialog:(void (^ )(void))cmpt;

- (void) showAlertOk:(NSString *)title Message:(NSString *)message onHander:(void(^)(NSInteger buttonIndex))hander;

@end
