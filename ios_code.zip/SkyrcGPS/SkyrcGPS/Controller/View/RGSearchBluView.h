//
//  RGSearchBluView.h
//  SkyrcGPS
//
//  Created by wsj on 2018/11/21.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NEDialog.h"
NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
    RGSearchTypeSearch = 0,//搜索框
    RGSearchTypeAlert  = 1,//提示框
} RGSearchType;

@interface RGSearchBluView : UIView

@property (nonatomic, assign) RGSearchType type;
- (void)showView;

@end

NS_ASSUME_NONNULL_END
