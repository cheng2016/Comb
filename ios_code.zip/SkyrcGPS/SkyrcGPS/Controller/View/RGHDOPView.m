//
//  RGHDOPView.m
//  SkyrcGPS
//
//  Created by wsj on 2018/12/3.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import "RGHDOPView.h"

@interface RGHDOPView ()
{
    CGFloat _width;
}
@property (nonatomic, strong) UIView *progressView;

@end

@implementation RGHDOPView

- (void)awakeFromNib
{
    [super awakeFromNib];
    _width = scrWidth - 60;
    self.progressView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, self.frame.size.height)];
    self.progressView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.progressView];
    self.clipsToBounds = YES;
}


-(void)setHDOP:(CGFloat)HDOP
{
    _HDOP = HDOP;
    CGFloat width = _width * HDOP / 10.0;
    if (HDOP <= 1) {
        self.progressView.backgroundColor = UIColorFromRGB(0X1e8f01);
    }else if (HDOP <= 2){
        self.progressView.backgroundColor = UIColorFromRGB(0Xd7d700);
    }else if (HDOP <= 5){
        self.progressView.backgroundColor = UIColorFromRGB(0Xd87500);
    }else{
        self.progressView.backgroundColor = UIColorFromRGB(0X8f0100);
    }
    [UIView animateWithDuration:1 animations:^{
        self.progressView.frame = CGRectMake(0, 0, width, self.frame.size.height);
    }];
    
}


@end
