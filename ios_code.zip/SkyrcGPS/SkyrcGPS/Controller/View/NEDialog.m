//
//  NEDialog.m
//  RevogiHome
//
//  Created by NEIL on 2017/2/8.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "NEDialog.h"

@interface NEDialog()

@property (nonatomic, strong) UIView *dialogView;

@property (nonatomic, strong) UIAlertView *alertView;

@property (copy) void(^alertHander)(NSInteger buttonIndex);

@end

@implementation NEDialog

+ (NEDialog *)shareManager {
    static dispatch_once_t onceToken;
    static NEDialog *_instance;
    dispatch_once(&onceToken, ^{
        _instance = [[NEDialog alloc] init];
    });
    return _instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self restoreDefault];

    }
    return self;
}

- (void)restoreDefault{
    self.style = PopStyleBottom;
    self.isCornerRadius = YES;
    self.duration = 0.35f;
}

- (void)dealloc
{
    
}

- (UIView *)createDialogView:(UIView *)dialogContainer{
    CGFloat cornerRadius = 8;
    dialogContainer.clipsToBounds = YES;
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = dialogContainer.bounds;
    gradient.colors = [NSArray arrayWithObjects:
                       (id)[[UIColor colorWithRed:228.0/255.0 green:228.0/255.0 blue:228.0/255.0 alpha:1.0f] CGColor],
                       (id)[[UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:1.0f] CGColor],
                       (id)[[UIColor colorWithRed:228.0/255.0 green:228.0/255.0 blue:228.0/255.0 alpha:1.0f] CGColor],
                       nil];
    
    gradient.cornerRadius = cornerRadius;
    [dialogContainer.layer insertSublayer:gradient atIndex:0];
    dialogContainer.layer.cornerRadius = cornerRadius;
    
    /* 阴影以及边框
    dialogContainer.layer.borderColor = [[UIColor colorWithRed:198.0/255.0 green:198.0/255.0 blue:198.0/255.0 alpha:1.0f] CGColor];
    dialogContainer.layer.borderWidth = 1;
    
    dialogContainer.layer.shadowRadius = cornerRadius + 5;
    dialogContainer.layer.shadowOpacity = 0.1f;
    dialogContainer.layer.shadowOffset = CGSizeMake(0 - (cornerRadius+5)/2, 0 - (cornerRadius+5)/2);
    dialogContainer.layer.shadowColor = [UIColor blackColor].CGColor;
    dialogContainer.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:dialogContainer.bounds cornerRadius:dialogContainer.layer.cornerRadius].CGPath;
     */
    return dialogContainer;
}



- (void)showDialog:(UIView *)dialogView  cmpt:(void (^ )(void))cmpt{
    self.frame = CGRectMake(0, 0, scrWidth, scrHeight);
    if (self.isCornerRadius) {
        self.dialogView = [self createDialogView:dialogView];
    } else {
        self.dialogView = dialogView;
    }
    self.dialogView.layer.shouldRasterize = YES;
    self.dialogView.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    
    self.layer.shouldRasterize = YES;
    self.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    [self addSubview:self.dialogView];
    [self popAnimate:self.style cmpt:cmpt];
}

- (void)dismissDialog:(void (^ )(void))cmpt{
    [self dismissAnimate:self.style cmpt:cmpt];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event touchesForView:self] anyObject];
    CGPoint location = [touch locationInView:self];
    if (location.x!=0 && location.y!=0 && self.isTouchHidden) {
        [self dismissAnimate:_style cmpt:nil];
    }
}

#pragma mark - Scene animation
- (void)popAnimate:(PopStyle)style cmpt:(void (^ )(void))cmpt{
    _isShow = YES;
    if (self.superView) {
        [self.superView addSubview:self];
    } else {
        [[UIApplication sharedApplication].keyWindow addSubview:self];
    }
    self.backgroundColor = UIColorWith256ARGB(0.0f, 0, 0, 0);
    self.dialogView.layer.opacity = 1.0f;
    
    CGPoint center = self.center;
    if (PopStyleDefault==style) {
        self.dialogView.center = center;
        self.dialogView.layer.opacity = 0.0f;
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.5f, 0, 0, 0);
                             self.dialogView.layer.opacity = 1.0f;
                         }
                         completion:^(BOOL finished) {
                             if (cmpt) cmpt();
                         }
         ];

    }else if (PopStyleTop==style){
        center.y = -self.dialogView.frame.size.height/2;
        self.dialogView.center = center;
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.5f, 0, 0, 0);
                             self.dialogView.center = CGPointMake(self.center.x, + self.dialogView.frame.size.height/2);
                         }
                         completion:^(BOOL finished) {
                             if (cmpt) cmpt();
                         }
         ];
    }else if (PopStyleBottom==style){
        center.y = self.frame.size.height + self.dialogView.frame.size.height/2;
        self.dialogView.center = center;
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.5f, 0, 0, 0);
                             self.dialogView.center = CGPointMake(self.center.x, self.frame.size.height-self.dialogView.frame.size.height/2);
                         }
                         completion:^(BOOL finished) {
                             if (cmpt) cmpt();
                         }
         ];
    }
}

- (void)dismissAnimate:(PopStyle)style cmpt:(void (^ )(void))cmpt{
    _isShow = NO;
    __block CGPoint center = self.center;
    if (PopStyleDefault==style) {
        center.y += 50;
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.0f, 0, 0, 0);
                             self.dialogView.layer.opacity = 0.0f;
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             [self removeFromSuperview];
                             if (cmpt) cmpt();
                             self.superView = nil;
                         }
         ];
        
    }else if (PopStyleTop==style){
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.0f, 0, 0, 0);
                             self.dialogView.center = CGPointMake(self.dialogView.center.x, - self.dialogView.frame.size.height/2);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             [self removeFromSuperview];
                             if (cmpt) cmpt();
                             self.superView = nil;
                         }
         ];
    }else if (PopStyleBottom==style){
        [UIView animateWithDuration:self.duration delay:0.0f options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             self.backgroundColor = UIColorWith256ARGB(0.0f, 0, 0, 0);
                             self.dialogView.center = CGPointMake(self.dialogView.center.x, self.frame.size.height + self.dialogView.frame.size.height/2);
                         }
                         completion:^(BOOL finished) {
                             for (UIView *v in [self subviews]) {
                                 [v removeFromSuperview];
                             }
                             [self removeFromSuperview];
                             if (cmpt) cmpt();
                             self.superView = nil;
                         }
         ];
    }
}


- (void) showAlertOk:(NSString *)title Message:(NSString *)message onHander:(void(^)(NSInteger buttonIndex))hander{
    self.alertHander = hander;
    _alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:NEString(@"ok") otherButtonTitles:nil];
    [self.alertView show];
}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (self.alertHander) {
        self.alertHander(buttonIndex);
    }
}

@end
