//
//  NELanguage.m
//  RevogiHome
//
//  Created by NEIL on 2017/1/3.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "NELanguage.h"


static NSString *kNELanguageCacheKey = @"kNELanguageCacheKey";

@interface NSString (SCLanguageManager)
- (BOOL)isEqualToLanguage:(NSString *)language;
@end


@interface NELanguage()

@property (assign, nonatomic) NSInteger type;
@property (strong, nonatomic) NSString *languageCodeText;
@property (strong, nonatomic) NSBundle *bundle;

@end

@implementation NELanguage

+ (NELanguage*)sharedManager {
    static NELanguage *_manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [[NELanguage alloc] init];
    });
    
    return _manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        NSString *presetLanguage = [userDefault objectForKey:kNELanguageCacheKey];
        self.languageCodeText = presetLanguage.length > 0 ? presetLanguage : [[NSLocale preferredLanguages] objectAtIndex:0];
        
        NSInteger index = 0;
        for (int i=0; i<kNELanguageCodeArray.count; i++) {
            if ([self.languageCodeText isEqualToLanguage:kNELanguageCodeArray[i]]) {
                index = i;
                break;
            }
        }
        self.languageCodeText = kNELanguageCodeArray[index];
        self.type = [kNELanguageTypeArray[index] integerValue];
        NSString *path = [[NSBundle mainBundle] pathForResource:self.languageCode ofType:@"lproj"];
        self.bundle  = [NSBundle bundleWithPath:path];
    }
    return self;
}


- (NELanguageType)languageType {
    return (NELanguageType)self.type;
}

- (NSUInteger)indexOfLanguages {
    return [kNELanguageTypeArray indexOfObject:@(self.type)];
}

- (NSString *)languageCode{
    return kNELanguageCodeArray[self.indexOfLanguages];
}


- (NSString *)languageText {
    return kNELanguageTextArray[self.indexOfLanguages];
}

- (NSString *)languageSymbol {
    return kNELanguageSymbolArray[self.indexOfLanguages];
}



- (void)changeLanguage:(NELanguageType)language{
    if (self.type == language) return;
    
    self.type = language;
    NSString *path = [[NSBundle mainBundle] pathForResource:self.languageCode ofType:@"lproj"];
    self.bundle  = [NSBundle bundleWithPath:path];
    [[NSUserDefaults standardUserDefaults] setObject:self.languageCode forKey:kNELanguageCacheKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:kNELanguageChangeNotifactionKey object:nil];
}

- (void)changeSensorLanguage:(NELanguageType)language{
    if (self.type == language) return;
    self.type = language;
    NSString *path = [[NSBundle mainBundle] pathForResource:self.languageCode ofType:@"lproj"];
    self.bundle  = [NSBundle bundleWithPath:path];
}


- (NSString*)getLocalizedString:(NSString*)key{
    if (!key) {
        return @"";
    }
    if(self.bundle)
        return [self.bundle localizedStringForKey:key value:nil table:nil];
    else{
        return key;
    }
}

@end


@implementation NSString (SCLanguageManager)

- (BOOL)isEqualToLanguage:(NSString *)language{
    if (!self || !language) return NO;
    if (self.length<language.length) return NO;
    if ([[self substringWithRange:NSMakeRange(0, language.length)] isEqualToString:language]) {
        return YES;
    }
    return NO;
}

@end
