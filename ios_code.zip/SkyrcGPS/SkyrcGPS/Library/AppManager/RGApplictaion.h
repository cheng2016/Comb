//
//  RGApplictaion.h
//  RevogiHome
//
//  Created by NEIL on 2017/1/7.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RGDevice.h"

static NSString *Devicearrykey = @"DeviceDcitkey";
static NSString *HistoryTimekey = @"HistoryTimekey";

#define RGAppManager    [RGApplictaion sharedManager]
#define RGConnectDevice RGAppManager.connectDevice

typedef NS_ENUM(NSInteger, CacheManagerType){
    CacheManagerTypeRead = 0,
    CacheManagerTypeupdate , //有则更新，无则添加
    CacheManagerTypeRemove
};
@interface RGApplictaion : NSObject

@property (nonatomic, strong) NSMutableArray<RGDevice *> *BluetoothListArray;//设备列表
@property (nonatomic, strong) RGDevice *connectDevice;
@property (nonatomic, assign) NSInteger unitType;//0：km/h  1:mile/h
@property (nonatomic, assign) CGFloat   unitConversion;//单位转换率

+ (instancetype)sharedManager;
- (void)cachedeviceManagerType:(CacheManagerType)managerType;


/**
 清除历史事件
 */
- (void)clearHistoryTime;

@end
