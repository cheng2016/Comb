//
//  RGDevice.h
//  蓄电池测量仪
//
//  Created by Revogi on 2018/10/9.
//  Copyright © 2018年 Revogi. All rights reserved.
//

//0：速度测试；1：距离测试；2：赛道模式；3：飞行模式；
typedef enum : NSUInteger {
    BluetoothTestTypeNone     = -200,//没有测试
    BluetoothTestTypeSpeed    = 0,//速度测试
    BluetoothTestTypeDistance = 1,//距离测试
    BluetoothTestTypeTrack    = 2,//赛道模式
    BluetoothTestTypeFlight   = 3,//飞行模式
    BluetoothTestTypeNOData   = 4,//没有数据
} BluetoothTestType;//设备测试类型

typedef enum : NSUInteger {
    BluetoothCodeTypSesion = 400,//超时
    BluetoothCodeTyppowerlow = 401,//设备电压不足
    BluetoothCodeTyppCorrent= 200,//成功
    BluetoothCodeTyppOffline= 500,//设备离线
    BluetoothCodeTypProgress= 101,//进度
    BluetoothCodeTypFailure = 000,//失败
} BluetoothCode;


typedef void(^RGProgressBlock)(CGFloat progress);
typedef void(^RGResultBlock)(BluetoothCode code, id data);
typedef void(^RGNullBlock)(void);



#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>
#import "RGTestResultModel.h"


@interface RGDevice : NSObject
@property (strong, nonatomic) CBPeripheral *devicePeripheral; // 蓝牙对象
@property (strong, nonatomic) NSString *name;  //名字
@property (strong, nonatomic) NSString *UUID;   //uuid ;

@property (assign, nonatomic) BOOL isOnline;//在线
@property (assign, nonatomic) NSInteger satellite;//卫星个数
@property (assign, nonatomic) NSInteger horizontalAccuracy;//水平精度系数 （扩大10倍）
@property (assign, nonatomic) NSInteger voltage;//电源电压 （电量）
@property (assign, nonatomic) BOOL isUnread;//是否有未读数据
@property (assign, nonatomic) BOOL isTest;//是否在测试中
@property (assign, nonatomic) BluetoothTestType currentType;//当前设备测试状态

@property (assign, nonatomic) NSTimeInterval lastHistoryTime;//最后时间戳，秒
@property (strong, nonatomic) NSMutableArray <RGTestResultModel *>*historyData;//历史数据
@property (strong, nonatomic) RGTestResultModel *firstResultModel;//最新一条数据
@property (strong, nonatomic) NSString *testString;

@property (strong, nonatomic) NSString *deviceInfo;
@property (strong, nonatomic) NSString *version;//固件版本号



@end



