//
//  NECentralManager.h
//  Switcher
//
//  Created by NEIL on 2017/3/5.
//  Copyright © 2017年 NEIL. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "RGDevice.h"

static NSString *NECentralManager_ConnectSuccess = @"NECentralManager_ConnectSuccess";
static NSString *NECentralManager_ConnectFailure = @"NECentralManager_ConnectFailure";
static NSString *NECentralManager_ConnectionLost = @"NECentralManager_ConnectionLost";
static NSString *ScanDidDeviceNotfication = @"ScanDeviceNotfication";


@interface NEBluetoothManager : NSObject


@property (nonatomic, copy) RGNullBlock     findNewBluetoothBlock;//发现新蓝牙设备回调
@property (nonatomic, copy) RGNullBlock     didStateChangeBlock;//状态变化回调
@property (nonatomic, copy) RGResultBlock   connectResultBlock;//连接蓝牙情况
@property (nonatomic, copy) RGNullBlock     realtimeRefreshBlock;//设备实时数据回调
@property (nonatomic, assign) BOOL isBluetoothEnable;//蓝牙是否可用
@property (nonatomic, strong) NSString *errorMessage; //蓝牙错误信息提示

//Singleton
+ (instancetype)sharedManager;

-(void)startscaningIsbackscandevice:(BOOL)backscandevice viewcontroller:(UIViewController *)fromController;
- (void)stopScanning;
- (void)connectDevice:(RGDevice *)device result:(RGResultBlock)block;//连接指定设备
- (void)disconnect:(CBPeripheral *)peripheral;
- (CBCentralManager *)_centralManager;






- (void)testTime:(NSData *)data;
- (void)getResult:(RGResultBlock)block index:(NSInteger)dex;
- (NSData *)CheckSum:(unsigned char *)recievePtr length:(NSUInteger)length;


@end

