//
//  NELanguage.h
//  RevogiHome
//
//  Created by NEIL on 2017/1/3.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *kNELanguageChangeNotifactionKey = @"kNELanguageChangeNotifactionKey";

//#define kNELanguageTypeArray @[@(NELanguageTypeEnglish), @(NELanguageTypeChinese), @(NELanguageTypeGerman), @(NELanguageTypeFrench), @(NELanguageTypeSpanish), @(NELanguageTypeDansk), @(NELanguageTypeCzech), @(NELanguageTypeMongolian)]
#define kNELanguageTypeArray @[@(NELanguageTypeEnglish), @(NELanguageTypeChinese),@(NELanguageTypeSlovak),@(NELanguageTypeSpanish),@(NELanguageTypeUkrainian),@(NELanguageTypeRussian), @(NELanguageTypeFrench),@(NELanguageTypeGerman),@(NELanguageTypeItaliano),@(NELanguageTypeCzech),@(NELanguageTypeTurkish)]

//#define kNELanguageCodeArray    @[@"en", @"zh-Hans", @"fr", @"de", @"es", @"da", @"cs", @"mn"]
#define kNELanguageCodeArray    @[@"en", @"zh-Hans",@"sk",@"es",@"uk",@"ru",@"fr",@"de",@"it",@"cs",@"tr"]


//#define kNELanguageSymbolArray  @[@"USD", @"CNY", @"DKK", @"FRF", @"ESP", @"DEM", @"CSK", @"MNT"]
#define kNELanguageSymbolArray  @[@"$/£", @"CNY",@"EUR",@"EUR",@"UAH",@"RUB",@"EUR",@"EUR",@"EUR",@"CZK",@"TRY"]


//#define kNELanguageTextArray    @[@"English", @"简体中文", @"Deutsch", @"Français", @"Español", @"Dansk", @"Čeština", @"Монгол хэл"]
#define kNELanguageTextArray    @[@"English", @"简体中文",@"Slovenčina",@"Español",@"Українська",@"Русский",@"Français",@"Deutsch",@"Italiano",@"Čeština",@"Turkish"]


// 0: 英语 1：中文 2：德语 3：法语 4：意大利语 5：西班牙 6：葡萄牙 7：日语 8:丹麦 9:荷兰 10:捷克语 11：韩语  12:蒙古语  13: 俄语 14：乌克兰语 15:斯洛伐克语 18://土耳其
typedef enum {
    NELanguageTypeEnglish   = 0, //英 @"en"
    NELanguageTypeChinese   = 1, //中 @"zh-Hans"
    NELanguageTypeGerman    = 2, //德 @"de"
    NELanguageTypeFrench    = 3, //法 @"fr"
    NELanguageTypeItaliano  = 4, //意大利
    NELanguageTypeSpanish   = 5, //西班牙 @"es"
    NELanguageTypeDansk     = 8, //丹麦 @"da"
    NELanguageTypeCzech     = 10,//捷克 @"cs"
    NELanguageTypeMongolian = 12,//蒙古 @"mn"
    NELanguageTypeRussian   = 13,//俄语 @"ru"
    NELanguageTypeUkrainian = 14,//乌克兰语@"uk"
    NELanguageTypeSlovak    = 15,//斯洛伐克语@"sk"
    NELanguageTypeTurkish   = 18,//土耳其
} NELanguageType;

@interface NELanguage : NSObject

+ (NELanguage*)sharedManager;

- (NELanguageType)languageType;

- (NSUInteger)indexOfLanguages;

- (NSString *)languageCode;

- (NSString *)languageText;

- (NSString *)languageSymbol;

- (void)changeLanguage:(NELanguageType)language;

- (void)changeSensorLanguage:(NELanguageType)language; 

- (NSString*)getLocalizedString:(NSString*)key;

@end
