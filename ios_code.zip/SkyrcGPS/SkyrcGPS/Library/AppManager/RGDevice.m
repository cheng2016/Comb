//
//  RGDevice.m
//  蓄电池测量仪
//
//  Created by Revogi on 2018/10/9.
//  Copyright © 2018年 Revogi. All rights reserved.
//

#import "RGDevice.h"

#define knotsUnit  (1.852)

@interface RGDevice ()

@property (nonatomic, assign) NSInteger historyCount; //请求第几个数据
@property (nonatomic, assign) NSInteger totalCount; //历史数据总个数

@property (strong, nonatomic) NSString *HTTableName;   //历史数据库表名


@end

@implementation RGDevice
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.historyData = [NSMutableArray array];
        self.currentType = BluetoothTestTypeNone;
        self.version = @"v1.0";
    }
    return self;
}

-(BOOL)isOnline
{
    return self.devicePeripheral.state == CBPeripheralStateConnected;
}

@end
