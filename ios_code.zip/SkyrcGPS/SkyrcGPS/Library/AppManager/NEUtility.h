//
//  NEUtility.h
//  NEUtility
//
//  Created by NEIL on 12/6/15.
//  Copyright (c) 2015 NEIL. All rights reserved.
//

#ifndef NEUtility_NEUtility_h
#define NEUtility_NEUtility_h
//#import <UIKit/UIKit.h>
#import "NELanguage.h"
#import "NEUtilityConstance.h"
#import "NEBluetoothManager.h"

#import "NEBaseViewController.h"
#import "RGDevice.h"
#import "RGApplictaion.h"
#import <Masonry.h>


#import <MBProgressHUD/MBProgressHUD.h>

#define WEAKSELF  __weak typeof(self) weakself = self;

#define Pre_voltagelowlimit 1220 //发动前电压
#define lowlimit 1330 //发动后电压差
#define highlimit 1530 //发动后电压

@interface NEUtility : NSObject<UIAlertViewDelegate>

+ (NSString*)getAppVersion;
+ (NSString*)getAppBuildVersion;
+ (NSString*)getAppName;

+ (void)afterTime:(float)time Action:(void(^)(void))action;
+ (BOOL)validateEmail:(NSString *)email;
+ (NSString *)md5Encryption16bit:(NSString *)input;
+ (NSString *)md5Encryption32bit:(NSString *)input;
+ (NSString *)docFilePath:(NSString* )fileName;
+ (NSString *)fetchSSID;
+ (UIImage *)screenShotAction;
+ (UIImage *)imageWithColor:(UIColor* )color;
+ (NSInteger)randomNumber:(NSInteger)from To:(NSInteger)to;
+ (NSInteger)createRuleID;
+ (NSInteger)weekForDate:(NSDate *)date;
+ (NSUInteger)timestamp;
+ (NSInteger)timestampZone;
+ (NSDate *)dateDayOffset:(NSInteger)offset FromDate:(NSDate *)date;
+ (NSDate *)dateMonthOffset:(NSInteger)offset FromDate:(NSDate *)date;

+(NSUInteger)PowerConversionElectricity:(NSInteger)power; //电池电压转换成电压
+ (void)jumpWiFiSetting;
+ (BOOL) justEmail:(NSString *)email;//邮箱验证
+ (BOOL) justMobile:(NSString *)mobile;//手机号码验证
+ (BOOL) justCarNo:(NSString *)carNo;//车牌号验证
+ (BOOL) justCarType:(NSString *)CarType;//车型
+ (BOOL) justUserName:(NSString *)name;//用户名
+ (BOOL) justPassword:(NSString *)passWord;//密码
+ (BOOL) justNickname:(NSString *)nickname;//昵称
+ (BOOL) justIdentityCard: (NSString *)identityCard;//身份证号
+ (UIImage *)getImageWithColor:(UIColor *)color;



/**
 判断2个时间戳是否同一天
 @param date1TimeInterval 时间戳
 @param date2TimeInterval 时间戳
 @return 返回是否同一天
 */
+ (BOOL)isSameDay:(NSTimeInterval)date1TimeInterval date2:(NSTimeInterval)date2TimeInterval;
/**
 查询输入时间戳与本地时间相差年份
 
 @param TimeInterval  输入时间戳
 @return 返回差的年份
 */
+ (NSInteger )dateyearOffsetFromTimeInterval:(NSTimeInterval)TimeInterval;
/**
 查询输入时间戳与本地时间相差月份
 
 @param TimeInterval  输入时间戳
 @return 返回差的月份
 */
+ (NSInteger )dateMonthOffsetFromTimeInterval:(NSTimeInterval)TimeInterval;


+ (NSInteger )dateDayOffsetFromTimeInterval:(NSTimeInterval)TimeInterval;


+ (NSInteger )datehourOffsetFromTimeInterval:(NSTimeInterval)TimeInterval;
/**
 * 64编码
 */
+ (NSString *)base64Encode:(NSString *)string;

/**
 * 64解码
 */
+ (NSString *)base64Dencode:(NSString *)base64String;


/**
 自定义字体
 */
+ (UIFont *)systemFontOfSize:(CGFloat)fontSize;

@end


#endif
