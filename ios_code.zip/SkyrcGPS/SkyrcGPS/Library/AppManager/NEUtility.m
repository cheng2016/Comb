
//
//  NEUtility.m
//  RevogiHome
//
//  Created by NEIL on 2016/12/30.
//  Copyright © 2016年 NEIL. All rights reserved.
//

#import "NEUtility.h"
#import <CommonCrypto/CommonDigest.h>
#import <SystemConfiguration/CaptiveNetwork.h>


//计算 IOS 的Tickout
#import<mach/mach_time.h>
uint64_t getTickCount(void)
{
    static mach_timebase_info_data_t sTimebaseInfo;
    uint64_t machTime = mach_absolute_time();
    
    // Convert to nanoseconds - if this is the first time we've run, get the timebase.
    if (sTimebaseInfo.denom == 0 )
    {
        (void) mach_timebase_info(&sTimebaseInfo);
    }
    // Convert the mach time to milliseconds
    uint64_t millis = ((machTime / 1000000) * sTimebaseInfo.numer) / sTimebaseInfo.denom;
    return millis;
}

@implementation NEUtility



+ (NSString*)getAppVersion {
    return [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
}

+ (NSString*)getAppBuildVersion {
    return [NSBundle mainBundle].infoDictionary[@"CFBundleVersion"];
}

+ (NSString*)getAppName {
    return [NSBundle mainBundle].infoDictionary[@"CFBundleDisplayName"];
}

+ (void)afterTime:(float)time Action:(void(^)(void))action{
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(time *NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        action();
    });
}

+ (BOOL)validateEmail:(NSString *)email {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

//依赖：#import <CommonCrypto/CommonDigest.h>
+ (NSString *)md5Encryption16bit:(NSString *)input {
    const char *str = [input UTF8String];
    unsigned char md[CC_MD5_DIGEST_LENGTH];
    CC_MD5(str, (CC_LONG)strlen(str), md);
    NSMutableString * ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    for (int i = 4; i < 12; i++) {
        [ret appendFormat:@"%02x",md[i]];
    }
    return ret;
}

+ (NSString *)md5Encryption32bit:(NSString *)input {
    const char *str = [input UTF8String];
    unsigned char md[CC_MD5_DIGEST_LENGTH];
    CC_MD5(str, (CC_LONG)strlen(str), md);
    NSMutableString * ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH*2];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [ret appendFormat:@"%02x",md[i]];
    }
    return ret;
}

+ (NSString *)docFilePath:(NSString* )fileName {
    NSArray* myPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* myDocPath = [myPaths objectAtIndex:0];
    NSString* filePath = [myDocPath stringByAppendingPathComponent:fileName];
    return filePath;
}

+ (UIImage *)screenShotAction {
    UIWindow *window = [UIApplication sharedApplication].windows.firstObject;
    UIGraphicsBeginImageContext(window.bounds.size);
    [window.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image= UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)imageWithColor:(UIColor* )color {
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

+ (NSString *)fetchSSID {
    NSArray *ifs = (id)CFBridgingRelease(CNCopySupportedInterfaces());
    id info = nil;
    for (NSString *ifnam in ifs) {
        info = ( id)CFBridgingRelease(CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam));
        if (info && [info count]) { break; }
    }
    return info[(__bridge NSString*)kCNNetworkInfoKeySSID];
}


+(NSInteger)randomNumber:(NSInteger)from To:(NSInteger)to{
    NSInteger number = from;
    number =  (NSInteger)(from + (arc4random()%(to-from+1)));
    return number;
}

+ (NSInteger)createRuleID {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HHmmss"];
    NSString* time = [formatter stringFromDate:[NSDate dateWithTimeIntervalSinceNow: 0/*(24 * 60 * 60)*/]];
    NSInteger shu= [self randomNumber:0 To:99];
    NSString * ruleID =[NSString stringWithFormat:@"%@%02d",time,(int)shu];
    return  [ruleID integerValue];
}

+ (NSInteger)weekForDate:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comps = [calendar components:(NSCalendarUnitWeekOfYear | NSCalendarUnitWeekday | NSCalendarUnitWeekdayOrdinal) fromDate:date];
    return [comps weekday];
}

+ (NSUInteger)timestamp{
    return [[NSDate date] timeIntervalSince1970] + [self timestampZone];
}

+ (NSInteger)timestampZone{
    return [[NSTimeZone systemTimeZone] secondsFromGMTForDate:[NSDate date]];
}


+ (NSDate *)dateDayOffset:(NSInteger)offset FromDate:(NSDate *)date{
    if(!date) return [NSDate date];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar components:(NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay)
                fromDate:date];
    
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    [adcomps setYear:0];
    [adcomps setMonth:0];
    [adcomps setDay:offset];
    
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:date options:0];
    return newdate;
}

+ (NSDate *)dateMonthOffset:(NSInteger)offset  FromDate:(NSDate *)date{
    if(!date) return [NSDate date];

    NSCalendar *calendar = [NSCalendar currentCalendar];
    [calendar components:(NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay)
                fromDate:date];
    
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    [adcomps setYear:0];
    [adcomps setMonth:offset];
    [adcomps setDay:offset];
    
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:date options:0];
    return newdate;
}
+(NSUInteger)PowerConversionElectricity:(NSInteger)power{
    if (power>1270) {
        return  100;
    }else if (power > 1250){
        return  (power-1250)*10/20+90;
    }else if (power > 1210){
        return  (power-1210)*40/40+50;
    }else if (power > 1190){
        return  (power-1190)*10/20+40;
    }else if(power > 1160){
        return  (power-1160)*20/30+20;
    }else if(power > 1130){
        return  (power-1130)*10/30+10;
    }else if(power > 1050){
        return  (power-1050)*10/80;
    }else{
        return 0;
    }
}
//+(NSUInteger)PowerConversionElectricity:(NSInteger)power{
//    if (power>1270) {
//        return  100;
//    }else if (power > 1240){
//        return  (power-1240)*25/30+75;
//    }else if(power > 1220){
//        return  (power-1220)*25/20+50;
//    }else if(power > 1190){
//        return  (power-1190)*50/30;
//    }else{
//        return 0;
//    }
//}

+ (void)jumpWiFiSetting{
 //   0x700x720x650x660x730x3a0x720x6f0x6f0x740x3d0x570x490x460x49
   // 0x410x700x700x2d0x500x720x650x660x730x3a0x720x6f0x6f0x740x3d0x570x490x460x49
    
    if ([[[UIDevice currentDevice] systemVersion] doubleValue] < 10.0) {
        NSData *encryptString = [[NSData alloc] initWithBytes:(unsigned char []){0x70,0x72,0x65,0x66,0x73,0x3a,0x72,0x6f,0x6f,0x74,0x3d,0x4e,0x4f,0x54,0x49,0x46,0x49} length:17];
        NSString *string = [[NSString alloc] initWithData:encryptString encoding:NSUTF8StringEncoding];
        if( [[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:string]] ) {
            [[UIApplication sharedApplication]openURL:[NSURL URLWithString:string]];
        }
    } else {
        NSData *encryptString = [[NSData alloc] initWithBytes:(unsigned char []){0x41,0x70,0x70,0x2d,0x50,0x72,0x65,0x66,0x73,0x3a,0x72,0x6f,0x6f,0x74,0x3d,0x57,0x49,0x46,0x49} length:19];
        NSString *string = [[NSString alloc] initWithData:encryptString encoding:NSUTF8StringEncoding];
        if( [[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:string]] ) {
            [[UIApplication sharedApplication]openURL:[NSURL URLWithString:string]];
        }
    }
}

//邮箱
+ (BOOL) justEmail:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


//手机号码验证
+ (BOOL) justMobile:(NSString *)mobile
{
    //手机号以13， 15，18开头，八个 \d 数字字符
    NSString *phoneRegex = @"^((13[0-9])|(15[^4,\\D])|(18[0,0-9]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}


//车牌号验证
+ (BOOL) justCarNo:(NSString *)carNo
{
    NSString *carRegex = @"^[\u4e00-\u9fa5]{1}[a-zA-Z]{1}[a-zA-Z_0-9]{4}[a-zA-Z_0-9_\u4e00-\u9fa5]$";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    return [carTest evaluateWithObject:carNo];
}


//车型
+ (BOOL) justCarType:(NSString *)CarType
{
    NSString *CarTypeRegex = @"^[\u4E00-\u9FFF]+$";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",CarTypeRegex];
    return [carTest evaluateWithObject:CarType];
}


//用户名
+ (BOOL) justUserName:(NSString *)name
{
    NSString *userNameRegex = @"^[A-Za-z0-9]{6,20}+$";
    NSPredicate *userNamePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",userNameRegex];
    BOOL B = [userNamePredicate evaluateWithObject:name];
    return B;
}


//密码
+ (BOOL) justPassword:(NSString *)passWord
{
    NSString *passWordRegex = @"^[a-zA-Z0-9]{8,20}+$";
    NSPredicate *passWordPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",passWordRegex];
    return [passWordPredicate evaluateWithObject:passWord];
}


//昵称
+ (BOOL) justNickname:(NSString *)nickname
{
    NSString *nicknameRegex = @"^[\u4e00-\u9fa5]{4,8}$";
    NSPredicate *passWordPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",nicknameRegex];
    return [passWordPredicate evaluateWithObject:nickname];
}


//身份证号
+ (BOOL) justIdentityCard: (NSString *)identityCard
{
    BOOL flag;
    if (identityCard.length <= 0) {
        flag = NO;
        return flag;
    }
    NSString *regex2 = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *identityCardPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    return [identityCardPredicate evaluateWithObject:identityCard];
}
+ (UIImage *)getImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    // 开始画图的上下文
    UIGraphicsBeginImageContext(rect.size);
    
    // 设置背景颜色
    [color set];
    // 设置填充区域
    UIRectFill(CGRectMake(0, 0, rect.size.width, rect.size.height));
    
    // 返回UIImage
    UIImage* image = UIGraphicsGetImageFromCurrentImageContext();
    // 结束上下文
    UIGraphicsEndImageContext();
    return image;
}



+ (BOOL)isSameDay:(NSTimeInterval)date1TimeInterval date2:(NSTimeInterval)date2TimeInterval
{
    NSCalendar* calendar = [NSCalendar currentCalendar];
    
    NSDate * date1 =[NSDate dateWithTimeIntervalSince1970:date1TimeInterval];
    NSDate * date2 =[NSDate dateWithTimeIntervalSince1970:date2TimeInterval];
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay;
    NSDateComponents* comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents* comp2 = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day]   == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year]  == [comp2 year];
}

+ (NSInteger )dateyearOffsetFromTimeInterval:(NSTimeInterval)TimeInterval{//年
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents * compments= [calendar components:NSCalendarUnitYear fromDate:[NSDate dateWithTimeIntervalSince1970:TimeInterval] toDate:[NEUtility zeroOfDate] options:NSCalendarWrapComponents];
    return compments.year;
}
+ (NSInteger )dateMonthOffsetFromTimeInterval:(NSTimeInterval)TimeInterval{//月
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents * compments= [calendar components:NSCalendarUnitMonth fromDate:[NSDate dateWithTimeIntervalSince1970:TimeInterval] toDate:[NEUtility zeroOfDate] options:NSCalendarWrapComponents];
    return compments.month%12;
}
+ (NSInteger )dateDayOffsetFromTimeInterval:(NSTimeInterval)TimeInterval{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents * compments= [calendar components:NSCalendarUnitHour fromDate:[NSDate dateWithTimeIntervalSince1970:TimeInterval] toDate:[NEUtility zeroOfDate] options:NSCalendarWrapComponents];
    NSLog(@"day = %ld",(long)(compments.hour+23)/24);
    return (compments.hour+23)/24;
}

+ (NSInteger )datehourOffsetFromTimeInterval:(NSTimeInterval)TimeInterval{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday |
    NSCalendarUnitHour | NSCalendarUnitMinute ;
    comps = [calendar components:unitFlags fromDate:[NSDate dateWithTimeIntervalSince1970:TimeInterval]];
    NSLog(@"hour %d",(int)comps.hour);
    return comps.hour;
}


+ (NSDate *)zeroOfDate
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSUIntegerMax fromDate:[NSDate date]];
    components.hour = 0;
    components.minute = 0;
    components.second = 0;
    NSTimeInterval ts = (double)(int)[[calendar dateFromComponents:components] timeIntervalSince1970];
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:ts];
    return date;
}


//64编码
+ (NSString *)base64Encode:(NSString *)string
{
    if (![string isKindOfClass:[NSString class]] || !string.length) {
        return @"";
    }
    //先将string转换成data
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *base64Data = [data base64EncodedDataWithOptions:0];
    
    NSString *baseString = [[NSString alloc]initWithData:base64Data encoding:NSUTF8StringEncoding];
    
    return baseString;
}

//64解码
+ (NSString *)base64Dencode:(NSString *)base64String{
    if (![base64String isKindOfClass:[NSString class]] || !base64String.length ) {
        return @"";
    }
    //NSData *base64data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *data = [[NSData alloc]initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    NSString *string = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    return string;
}


+ (UIFont *)systemFontOfSize:(CGFloat)fontSize
{
    return [UIFont fontWithName:kNECustomFontName size:fontSize];
}
@end
