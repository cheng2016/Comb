//
//  RGApplictaion.m
//  RevogiHome
//
//  Created by NEIL on 2017/1/7.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "RGApplictaion.h"



@interface RGApplictaion()



@end

@implementation RGApplictaion {
    NSUserDefaults *userDefaults;
}

+ (instancetype)sharedManager{
    static RGApplictaion *_application;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _application = [[RGApplictaion alloc] init];
        [_application cachedeviceManagerType:CacheManagerTypeRead];
    });
    
    return _application;
}
-(void)setUnitType:(NSInteger)unitType
{
    _unitType = unitType;
    [userDefaults setInteger:unitType forKey:@"GPSUnitType"];
    [userDefaults synchronize];
}
-(CGFloat)unitConversion
{
    if (self.unitType) {
        return 0.6213711;
    }
    return 1;
}


- (instancetype)init{
    self = [super init];
    if (self) {
        _BluetoothListArray  =[[NSMutableArray alloc] init];
        userDefaults = [NSUserDefaults standardUserDefaults];
        self.unitType = [userDefaults integerForKey:@"GPSUnitType"];
    }
    return self;
}

#pragma mark - 存储设备列表
- (void)cachedeviceManagerType:(CacheManagerType)managerType {
    if (managerType==CacheManagerTypeRead) {//
        if ([userDefaults objectForKey:Devicearrykey]) {
            NSDictionary *devicedic = [userDefaults valueForKey:Devicearrykey];
            RGDevice *device =[[RGDevice alloc] init];
            if (!self.connectDevice) self.connectDevice = device;
            self.connectDevice.name = devicedic[@"name"];
            self.connectDevice.UUID = devicedic[@"UUID"];
            if ([userDefaults objectForKey:HistoryTimekey]) {
                NSDictionary *timeDic = [userDefaults valueForKey:HistoryTimekey];
                self.connectDevice.lastHistoryTime = [timeDic[device.UUID] doubleValue];
            }
        }
        
    }else if (managerType==CacheManagerTypeupdate && self.connectDevice){
        //更新数据
        RGDevice *device = self.connectDevice;
        NSDictionary *devicedic = @{@"name":device.name?device.name:@"",
                                    @"UUID":device.UUID?device.UUID:@"",
                                    };
        [userDefaults setObject:devicedic forKey:Devicearrykey];

        NSDictionary *timeDic = [userDefaults valueForKey:HistoryTimekey];
        NSMutableDictionary *mutableDic = [[NSMutableDictionary alloc] initWithDictionary:timeDic];
        [mutableDic setValue:@(device.lastHistoryTime) forKey:device.UUID];
        [userDefaults setObject:mutableDic forKey:HistoryTimekey];
        
        [userDefaults synchronize];
        
    }
}
- (void)clearHistoryTime
{
    [RGConnectDevice.historyData removeAllObjects];
    RGConnectDevice.lastHistoryTime = 0;
    [userDefaults setObject:@{} forKey:HistoryTimekey];
}



@end
