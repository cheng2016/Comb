//
//  RGTestResultModel.m
//  SkyrcGPS
//
//  Created by wsj on 2018/11/24.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import "RGTestResultModel.h"

@implementation RGTestResultModel

-(instancetype)init
{
    if ( self = [super init] ) {
        self.speeds = [NSMutableArray array];
        self.slopes = [NSMutableArray array];
        self.accelerations = [NSMutableArray array];
        self.minA = 99999;
        self.minSlope = 9999;
        self.minSpeed = 9999;
        self.testName = @"";
        self.time = 123456;
        self.isData = 1;
    }
    return self;
}

-(NSArray<NSDictionary *> *)dataSource
{
    switch (self.type) {
        case BluetoothTestTypeSpeed:
        {
            NSString *speedF = [NSString stringWithFormat:@"%ld-%ld%@",self.startSpeed,self.endSpeed,NEString(@"speedUnit")];
            NSString *maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed,NEString(@"speedUnit")];
            if (RGAppManager.unitType) {
                speedF = [NSString stringWithFormat:@"%0.0lf-%0.0lf%@",self.startSpeed * RGAppManager.unitConversion,self.endSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
                maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
            }
            NSMutableArray *arrays = [NSMutableArray array];
            [arrays addObject:@{@"left":NEString(@"test_Model"),         @"right":self.testName}];
            [arrays addObject:@{@"left":NEString(@"test_Speed"),         @"right":speedF}];
            [arrays addObject:@{@"left":NEString(@"Use_time"),           @"right":[NSString stringWithFormat:@"%ld'%ld.%@\"",self.useMinute,self.useSecond,[NSString stringWithFormat:@"%02ld",self.millisecond]]}];
            [arrays addObject:@{@"left":NEString(@"test_acceleration"),  @"right":[NSString stringWithFormat:@"%0.2lfg",self.maxA]}];
            return arrays;
//                     @{@"left":NEString(@"test_slope"),         @"right":[NSString stringWithFormat:@"%0.2lf%%",self.maxSlope],},
        }
            break;
        case BluetoothTestTypeDistance:
        {
            NSString *speedF = [NSString stringWithFormat:@"%ld-%ld%@",self.startSpeed,self.endSpeed,NEString(@"distanceUnit")];
            NSString *maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed,NEString(@"speedUnit")];
            if (RGAppManager.unitType) {
                speedF = [NSString stringWithFormat:@"%0.0lf-%0.0lf%@",self.startSpeed * RGAppManager.unitConversion,self.endSpeed * RGAppManager.unitConversion,NEString(@"distanceUnitM")];
                maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
            }
            NSMutableArray *arrays = [NSMutableArray array];
            [arrays addObject:@{@"left":NEString(@"test_Model"),         @"right":self.testName}];
            [arrays addObject:@{@"left":NEString(@"test_Distance"),      @"right":speedF}];
            [arrays addObject:@{@"left":NEString(@"Use_time"),           @"right":[NSString stringWithFormat:@"%ld'%ld.%@\"",self.useMinute,self.useSecond,[NSString stringWithFormat:@"%02ld",self.millisecond]]}];
            [arrays addObject:@{@"left":NEString(@"test_maxSpeed"),      @"right":maxSpeed}];
            [arrays addObject:@{@"left":NEString(@"test_acceleration"),  @"right":[NSString stringWithFormat:@"%0.2lfg",self.maxA]}];
            return arrays;
//            @{@"left":NEString(@"test_slope"),         @"right":[NSString stringWithFormat:@"%0.2lf%%",self.maxSlope],}
        }
            break;
        case BluetoothTestTypeTrack:
        {
            NSString *speedF = [NSString stringWithFormat:@"%ld%@",self.startSpeed,NEString(@"distanceUnit")];
            NSString *velocity = [NSString stringWithFormat:@"%0.0lf%@",self.averageSpeed,NEString(@"speedUnit")];
            NSString *maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed,NEString(@"speedUnit")];
            if (RGAppManager.unitType) {
                speedF = [NSString stringWithFormat:@"%0.0lf%@",self.startSpeed * RGAppManager.unitConversion,NEString(@"distanceUnitM")];
                velocity = [NSString stringWithFormat:@"%0.0lf%@",self.averageSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
                maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
            }
            NSMutableArray *arrays = [NSMutableArray array];
            [arrays addObject:@{@"left":NEString(@"test_Model"),         @"right":self.testName}];
            [arrays addObject:@{@"left":NEString(@"Distance"),           @"right":speedF}];
            [arrays addObject:@{@"left":NEString(@"Use_time"),           @"right":[NSString stringWithFormat:@"%ld'%ld\"",self.useMinute,self.useSecond]}];
            [arrays addObject:@{@"left":NEString(@"average_velocity"),   @"right":velocity}];
            [arrays addObject:@{@"left":NEString(@"max_speed"),          @"right":maxSpeed}];
            [arrays addObject:@{@"left":NEString(@"test_slope"),         @"right":[NSString stringWithFormat:@"%0.2lf%%",self.maxSlope],}];
            return arrays;
        }
            break;
        case BluetoothTestTypeFlight:
        {
            NSString *speedF = [NSString stringWithFormat:@"%ld%@",self.startSpeed,NEString(@"distanceUnit")];
            NSString *velocity = [NSString stringWithFormat:@"%0.0lf%@",self.averageSpeed,NEString(@"speedUnit")];
            NSString *maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed,NEString(@"speedUnit")];
            NSString *maxHeight = [NSString stringWithFormat:@"%0.0lf%@",self.maxHeight,NEString(@"distanceUnit")];
            if (RGAppManager.unitType) {
                speedF = [NSString stringWithFormat:@"%0.0lf%@",self.startSpeed * RGAppManager.unitConversion,NEString(@"distanceUnitM")];
                velocity = [NSString stringWithFormat:@"%0.0lf%@",self.averageSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
                maxSpeed = [NSString stringWithFormat:@"%0.0lf%@",self.maxSpeed * RGAppManager.unitConversion,NEString(@"speedUnitM")];
                maxHeight = [NSString stringWithFormat:@"%0.0lf%@",self.maxHeight * RGAppManager.unitConversion,NEString(@"distanceUnitM")];
            }
            NSMutableArray *arrays = [NSMutableArray array];
            [arrays addObject:@{@"left":NEString(@"test_Model"),         @"right":self.testName}];
            [arrays addObject:@{@"left":NEString(@"Distance"),           @"right":speedF}];
            [arrays addObject:@{@"left":NEString(@"Use_time"),           @"right":[NSString stringWithFormat:@"%ld'%ld\"",self.useMinute,self.useSecond]}];
            [arrays addObject:@{@"left":NEString(@"average_velocity"),   @"right":velocity}];
            [arrays addObject:@{@"left":NEString(@"max_speed1"),         @"right":maxSpeed}];
            [arrays addObject:@{@"left":NEString(@"max_heigth"),         @"right":maxHeight,}];
            return arrays;
        }
            break;
            
        default:
            break;
    }
    return @[];
}
-(NSString *)testName
{
    switch (self.type) {
        case BluetoothTestTypeSpeed:
            _testName = NEString(@"speedTest");
            break;
        case BluetoothTestTypeDistance:
            _testName = NEString(@"distanceTest");
            break;
        case BluetoothTestTypeTrack:
            _testName = NEString(@"trackName");
            break;
        case BluetoothTestTypeFlight:
            _testName = NEString(@"flight");
            break;
        default:
            break;
    }
    return _testName;
}

- (void)selectArrays
{
    
}
- (void)saveArrays
{
    
}

@end
