//
//  RGSatelliteObject.h
//  SkyrcGPS
//
//  Created by Revogi on 2018/11/24.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RGSatelliteObject : NSObject
@property(assign, nonatomic) NSInteger  signal;
@property(assign,nonatomic)  NSString *SatelliteId;
@end

NS_ASSUME_NONNULL_END
