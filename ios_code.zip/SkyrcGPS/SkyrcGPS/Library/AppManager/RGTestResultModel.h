//
//  RGTestResultModel.h
//  SkyrcGPS
//
//  Created by wsj on 2018/11/24.
//  Copyright © 2018年 wsj. All rights reserved.
//

#import <Foundation/Foundation.h>

//typedef enum : NSUInteger {
//    KTestTypeSpeed,    //速度测试
//    KTestTypeDistance, //距离测试
//    KTestTypeTrack,    //赛道测试
//    KTestTypeFlight,   //飞行测试
//} KTestType;
NS_ASSUME_NONNULL_BEGIN



@interface RGTestResultModel : NSObject

@property (nonatomic, assign) NSInteger type;
@property (nonatomic, strong) NSString *testName;
@property (nonatomic, assign) NSInteger startSpeed;   //开始速度
@property (nonatomic, assign) NSInteger endSpeed;     //结束速度
@property (nonatomic, assign) NSInteger useMinute;    //分钟
@property (nonatomic, assign) NSInteger useSecond;    //秒
@property (nonatomic, assign) NSInteger millisecond;    //毫秒
@property (nonatomic, strong) NSMutableArray *accelerations;//加速度数组：(最大存60秒，每秒10个) ：单位为g  1m/s2=9.8g
@property (nonatomic, strong) NSMutableArray *slopes;//坡度数组：(最大存60秒，每秒10个) ：单位为m
@property (nonatomic, strong) NSMutableArray *speeds;//速度数组：(最大存60秒，每秒10个) ：单位为km/h
@property (nonatomic, assign) CGFloat maxSpeed;     //最大速度：单位为km/h
@property (nonatomic, assign) CGFloat minSpeed;     //最小速度：单位为km/h
@property (nonatomic, assign) CGFloat averageSpeed; //平均速度：单位为km/h
@property (nonatomic, assign) CGFloat maxA;         //最大加速度：单位为g
@property (nonatomic, assign) CGFloat minA;         //最小加速度：单位为g
@property (nonatomic, assign) CGFloat maxHeight;    //最大高度：单位为m
@property (nonatomic, assign) CGFloat maxSlope;     //最大坡度：单位%
@property (nonatomic, assign) CGFloat minSlope;     //最小坡度：单位%

@property (nonatomic, assign) NSInteger year;   //年
@property (nonatomic, assign) NSInteger month;  //月
@property (nonatomic, assign) NSInteger day;    //日
@property (nonatomic, assign) NSInteger hour;   //时
@property (nonatomic, assign) NSInteger minute; //分
@property (nonatomic, assign) NSInteger second; //秒
@property (nonatomic, assign) NSInteger dataID; //数据id
@property (nonatomic, assign) NSTimeInterval time;//时间戳

@property (nonatomic, assign) NSInteger isData;  //是否设备有数据 YES：有数据 NO：没数据
@property (nonatomic, assign) NSInteger isCache; //是否缓存过

@property (nonatomic, strong) NSArray <NSDictionary *> *dataSource;

- (void)selectArrays;
- (void)saveArrays;

@end

NS_ASSUME_NONNULL_END
