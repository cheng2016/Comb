//
//  NECentralManager.m
//  Switcher
//
//  Created by NEIL on 2017/3/5.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "NEBluetoothManager.h"
#import <UIKit/UIKit.h>
#import "BLEUtility.h"
#include <sys/socket.h>
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>


#define    BT_SERVICE_UUID                     @"fff0"//服务uuid
#define    BT_NOTIFICATION_UUID                @"fff4"//通知uuid
#define    BT_READ_WRITE_UUID                  @"fff1"//升级和16位码读写uuid
#define    BT_WRITE_UUID                       @"fff3"//写
#define    BT_READNAME_UUID                    @"fff6"//读取设备名称
#define    BT_DATA_UUID                        @"fff2"//获取HDOP等实时数据
#define    BT_DATA_Test                        @"fff5"//测试


typedef NS_ENUM(NSInteger, DeviceCmdType){
    //local
    DeviceCmdTypeLineTest       = 0x01,//直线测试
    DeviceCmdTypeLineData       = 0x02,//获取直线数据
    DeviceCmdTypeTrackFlight    = 0x03,//赛道和飞行测试
    DeviceCmdTypeTrackData      = 0x04,//获取赛道/飞行模式数据
    DeviceCmdTypesGettarttest   = 0x05, //
    DeviceCmdTypesHistoryList   = 0x06, //历史成绩列表
    DeviceCmdTypesHistoryData   = 0x07, //获取历史数据单条详情
    DeviceCmdTypesClearCache    = 0x08, //上位机发送清除历史缓存的命令
    DeviceCmdTypesEndTest       = 0x09, //上位机发送结束测试的命令
    DeviceCmdTypesGetibeacnuuid = 0x1A, //

};

@interface NEBluetoothManager() <CBCentralManagerDelegate, CBPeripheralDelegate>

@property (nonatomic, weak) UIViewController *fromController;
@property (nonatomic, strong) CBCentralManager *centralManager;

@property (nonatomic, copy) RGResultBlock getdataBlock;//返回结果

@end

@implementation NEBluetoothManager{
    RGDevice *_device;
    RGResultBlock _resultBlock;
    NSData * writeData;
    BOOL _initCentralManager;
    NSTimer *backgrounScanTimer;
    NSMutableData *_recieveData;//收到的多包数据;
    NSInteger historylenth ;
    
    BOOL _isTestModel;      //飞行和赛道测试
    BOOL _isTestDataModel;  //飞行和赛道测试结果数据
    BOOL _isLineTestModel;  //直线测试
    BOOL _isLineTestDataModel;//直线测试结果数据
    BOOL _isEndTest;        //结束测试
    
    BOOL _isHistoryList;    //历史数据
    BOOL _isHistoryData;    //历史详情数据
    BOOL _isClearCache;     //清除缓存
    
}

+ (instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static NEBluetoothManager *_instance = nil;
    dispatch_once(&onceToken, ^{
        [RGApplictaion sharedManager];
        _instance = [[NEBluetoothManager alloc] init];
    });
    return _instance;
}

- (id)init {
    if (self = [super init]) {
        self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        _recieveData=[[NSMutableData alloc] init];
        historylenth = 0 ; 
    }
    return self;
}

- (CBCentralManager *)_centralManager{
    return self.centralManager;
}

-(void)startscaningIsbackscandevice:(BOOL)backscandevice viewcontroller:(UIViewController *)fromController{
    self.fromController = fromController;
    if (self.isBluetoothEnable) {
        [self.centralManager scanForPeripheralsWithServices:nil options:nil];//广播扫描周边蓝牙设备
        NSLog(@"Scanning started");
    } else if (_initCentralManager && fromController){
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:self.errorMessage message:nil preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NEString(@"ok") style:UIAlertActionStyleDefault handler:nil]];
        [self.fromController presentViewController:alert animated:YES completion:nil];
    }
}
- (void)connectDevice:(RGDevice *)device result:(RGResultBlock)block
{
    _resultBlock = block;
    _device = device;
    NSDictionary *timeDic = [[NSUserDefaults standardUserDefaults] valueForKey:HistoryTimekey];
    _device.lastHistoryTime = [timeDic[_device.UUID] doubleValue];
    [self performSelector:@selector(stopScanning) withObject:nil afterDelay:5];
    [self.centralManager connectPeripheral:device.devicePeripheral options:nil];
}


- (void)stopScanning {
    if (!RGConnectDevice.isOnline) {
        if (self.connectResultBlock) self.connectResultBlock(BluetoothCodeTypFailure,@"Blu_disconnect");
        if (_resultBlock) _resultBlock(BluetoothCodeTypFailure,@"Blu_disconnect");
    }
    self.fromController = nil;
    [self.centralManager stopScan];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(stopScanning) object:nil];
    NSLog(@"stop");
}

/**
 后台扫描蓝牙设备
 */
-(void)backgroudScanTimer{
    if (backgrounScanTimer==nil) {
        backgrounScanTimer = [NSTimer scheduledTimerWithTimeInterval:15.0 target:self selector:@selector(reconnectDevice) userInfo:nil repeats:YES];
//        [self performSelector:@selector(stopScanning) withObject:nil afterDelay:10];
    }
}
/**
 重新连接蓝牙设备
 */
- (void)reconnectDevice
{
    if (RGConnectDevice.isOnline) {
        return;
    }
    if (!_isBluetoothEnable) {
        if (self.connectResultBlock) self.connectResultBlock(BluetoothCodeTypFailure,nil);
        return;
    }
    if (RGConnectDevice) {
        [self startscaningIsbackscandevice:YES viewcontroller:nil];
    }
}

#pragma mark - CBCentralManagerDelegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    NSLog(@"[central state] --%d",(int)[central state]);
    if ([central state] == CBCentralManagerStatePoweredOff) {
        self.isBluetoothEnable = NO;
        self.errorMessage = NEString(@"open_ble");
    }
    else if ([central state] == CBCentralManagerStatePoweredOn){
        self.isBluetoothEnable = YES;
        [self reconnectDevice];
        [self backgroudScanTimer];
    }
    else if ([central state] == CBCentralManagerStateUnauthorized) {
        self.isBluetoothEnable = NO;
        self.errorMessage = NEString(@"open_ble");
    }
    else if ([central state] == CBCentralManagerStateUnknown) {
        self.isBluetoothEnable = NO;
            self.errorMessage = NEString(@"open_ble");
    }
    else if ([central state] == CBCentralManagerStateUnsupported) {
        self.isBluetoothEnable = NO;
            self.errorMessage = NEString(@"open_ble");
    }
    if (self.didStateChangeBlock) {
        self.didStateChangeBlock ();
    }
    _initCentralManager = YES;
}
//完成设备连接服务
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"Peripheral Connected");
    RGAppManager.connectDevice = _device;
    [RGAppManager cachedeviceManagerType:CacheManagerTypeupdate];
    if (_resultBlock) _resultBlock(BluetoothCodeTyppCorrent,peripheral);
    if (_connectResultBlock) _connectResultBlock(BluetoothCodeTyppCorrent,peripheral);
    [self stopScanning];
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:NECentralManager_ConnectSuccess object:nil userInfo:@{@"peripheral": peripheral}];
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {//扫描到设备之后调用
    NSLog(@"advertisementData:%@",advertisementData[@"kCBAdvDataLocalName"]);
    NSLog(@"RSSI:%i",[RSSI intValue]);//  SATECHIPLUG VEMITER CLIPMETER
    @try {
        if(([[advertisementData valueForKey:@"kCBAdvDataLocalName"] rangeOfString:@"PetComb"].length != 0)
           && [RSSI intValue]>-95 && [RSSI intValue]!=127){
            NSLog(@"peripheral:%@",peripheral.name);
            NSLog(@"advertisementData:%@",advertisementData);
            NSLog(@"RSSI:%i",[RSSI intValue]);
            NSData *macData = [advertisementData valueForKey:@"kCBAdvDataManufacturerData"];
            const unsigned char *rePtr = [macData bytes];
            NSMutableString *dataString = [NSMutableString stringWithCapacity:(2*macData.length)];
            for (NSUInteger i = 0; i<macData.length; i++,rePtr++) {
                [dataString appendFormat:@"%02lX",(long)*rePtr];
            }
            NSString *peripheralName = [NSString stringWithFormat:@"GPS%@%@",[dataString substringWithRange:NSMakeRange(6, 2)],[dataString substringWithRange:NSMakeRange(4, 2)]];
            if(peripheral.identifier.UUIDString!=nil){
                BOOL haveDevice = NO;
                for(int i=0;i<RGAppManager.BluetoothListArray.count;i++){
                    RGDevice *device = [RGAppManager.BluetoothListArray objectAtIndex:i];
                    if ([device.UUID isEqualToString:peripheral.identifier.UUIDString] ) {
                        device.UUID = peripheral.identifier.UUIDString;
                        device.name = peripheralName;
                        device.devicePeripheral = peripheral;
                        NSLog(@"peripheral local Name:%@",[advertisementData objectForKey:CBAdvertisementDataLocalNameKey]);
                        [RGAppManager.BluetoothListArray replaceObjectAtIndex:i withObject:device];
                        if ([RGConnectDevice.UUID isEqualToString:device.UUID]) {
                            RGConnectDevice.devicePeripheral = peripheral;
                            [self connectDevice:RGConnectDevice result:nil];
                        }
                        haveDevice = YES;
                        break;
                    }
                }
                if(!haveDevice){
                    RGDevice *addDevice = [[RGDevice alloc]init];
                    addDevice.devicePeripheral = peripheral;
                    addDevice.name = peripheralName;
                    addDevice.UUID = peripheral.identifier.UUIDString;
                    [RGAppManager.BluetoothListArray addObject:addDevice];
                    if (self.findNewBluetoothBlock) self.findNewBluetoothBlock();
                    if ([RGConnectDevice.UUID isEqualToString:addDevice.UUID]) {
                        RGConnectDevice.devicePeripheral = peripheral;
                        [self connectDevice:RGConnectDevice result:nil];
                    }
                }
            }
        }
    }
    @catch (NSException *exception) {
    }
}
#pragma mark - CBPeripheralDelegate
//完成发现服务
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    
    NSLog(@"发现服务");
    
    if (error) {
        NSLog(@"Error discovering services: %@", [error localizedDescription]);
        return;
    }
    @try {
        for (CBService *service in peripheral.services){
            if ([service.UUID isEqual:[CBUUID UUIDWithString:BT_SERVICE_UUID]]) {//查找我们需要的服务
                [peripheral discoverCharacteristics:nil forService:service ];
                break;
            }
        }
    }
    @catch (NSException *exception) {
    }
}
-(void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    
}
//建立服务发送数据
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    NSLog(@"didDiscoverCharacteristicsForService");
    if (error) {
        NSLog(@"Error discovering characteristics: %@", [error localizedDescription]);
        return;
    }else{
        for (CBCharacteristic *characteristic in service.characteristics) {//查找我们需要的特性
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_NOTIFICATION_UUID]]) {//通知uuid
                [BLEUtility setNotificationForCharacteristic:peripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_NOTIFICATION_UUID] enable:YES];
            }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_READ_WRITE_UUID]]){//升级和16位码读写uuid
                [BLEUtility readCharacteristic:peripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_READ_WRITE_UUID]];
            }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_WRITE_UUID]]){//读写uuid
//                [self sendDate:peripheral];
//                [self getBatteryreplacementtime:peripheral cmpt:nil];
//                [self getibeaconuuid:peripheral cmpt:nil];
            }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_DATA_UUID]]){
                [self getRealDHOP];
            }else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_READNAME_UUID]]){
                [BLEUtility readCharacteristic:peripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_READNAME_UUID]];
            }
        }
    }
}
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    if (_resultBlock) _resultBlock(BluetoothCodeTypFailure,peripheral);
    if (_connectResultBlock) _connectResultBlock(BluetoothCodeTyppCorrent,peripheral);
    [self reconnectDevice];
     NSLog(@"Failed to connect to %@. (%@)", peripheral, [error localizedDescription]);
    [[NSNotificationCenter defaultCenter] postNotificationName:NECentralManager_ConnectFailure object:nil userInfo:@{@"peripheral": peripheral}];
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    if (_resultBlock) _resultBlock(BluetoothCodeTyppOffline,peripheral);
    if (_connectResultBlock) _connectResultBlock(BluetoothCodeTyppCorrent,peripheral);
    [self reconnectDevice];
    NSLog(@"Peripheral Disconnected");
    NSLog(@"Peripheral Disconnected error:%@",error);
    NSLog(@"peripheral.UUID:%@",[peripheral.identifier UUIDString]);
    [[NSNotificationCenter defaultCenter] postNotificationName:NECentralManager_ConnectionLost object:nil userInfo:@{@"peripheral": peripheral}];
}

//收到的数据
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
//    NSLog(@"\ndidUpdateValueForCharacteristic");
    
    if (error) {
        NSLog(@"Error discovering characteristics: %@", [error localizedDescription]);
        return;
    }else{
        @try {
            NSUInteger dataLength = [characteristic.value length];
            const unsigned char *recievePtr = [characteristic.value bytes];
            NSLog(@"\ndidUpdateValueForCharacteristic \ndevice UUID:%@",characteristic.UUID);
            for (int i=0; i<dataLength; i++) {
                printf("recievePtr[%i]--%02x\n",i,recievePtr[i]);
            }
            printf("\n");
            
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_DATA_UUID]]) {
//                [RGConnectDevice recieveDHOP:recievePtr];
                if (self.realtimeRefreshBlock) self.realtimeRefreshBlock();
            }if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_DATA_Test]]) {
                NSInteger IR =  [[NSNumber numberWithUnsignedChar:recievePtr[0]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recievePtr[1]]intValue];
                NSInteger PSData =  [[NSNumber numberWithUnsignedChar:recievePtr[2]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recievePtr[3]]intValue];
                NSInteger QT =  [[NSNumber numberWithUnsignedChar:recievePtr[4]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recievePtr[5]]intValue];
                
                RGConnectDevice.testString = [NSString stringWithFormat:@"IR：%ld  \nPSDATA：%ld  \nQT：%ld",IR,PSData,QT];
            }else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_READNAME_UUID]]){//获取名字;
                NSString *nameString = [[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];
                RGConnectDevice.name = nameString;
                if (_connectResultBlock) _connectResultBlock(BluetoothCodeTyppCorrent,nil);
            }else if([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_READ_WRITE_UUID]]){
                if (dataLength == 16) {
                    NSMutableString *dataString = [NSMutableString stringWithCapacity:(2*dataLength)];
                    for (NSUInteger i = 0; i<dataLength; i++,recievePtr++) {
                        [dataString appendFormat:@"%02lX",(long)*recievePtr];
                    }
                    RGConnectDevice.deviceInfo = [NSString stringWithString:dataString];
                    recievePtr = [characteristic.value bytes];
                    RGConnectDevice.version = [NSString stringWithFormat:@"v%d.%02d",[[NSNumber numberWithUnsignedChar:recievePtr[11]]intValue],[[NSNumber numberWithUnsignedChar:recievePtr[12]]intValue]];
                }
                
            }else if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:BT_NOTIFICATION_UUID]]){
                if (_isTestModel) {//赛道和飞行测试
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypeTrackFlight){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
                        BOOL resultB = [[NSNumber numberWithUnsignedChar:recievePtr1[4]] boolValue];
                        [self getRealDHOP];
                        _getdataBlock(resultB ? BluetoothCodeTypFailure : BluetoothCodeTyppCorrent ,nil);
                    }
                }else if (_isTestDataModel) {//赛道和飞行测试结果数据
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypeTrackData){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
//                        [RGConnectDevice recieveTrackOrFlightTestResultData:_recieveData];
                        _getdataBlock(BluetoothCodeTyppCorrent,nil);
                    }
                }else if (_isLineTestModel) {//直线测试
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypeLineData){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
                        const unsigned char *recieveData = [_recieveData bytes];
                        NSString *resultText = [NSString stringWithFormat:@"查询结果：\n模式：%ld   Repeat:%ld \n规则1：IR亮度：%ld  时间：%lds\n            RED亮度：%ld  时间：%lds\n规则2：IR亮度：%ld  时间：%lds\n            RED亮度：%ld  时间：%lds",recieveData[4],recieveData[5],recieveData[6],[[NSNumber numberWithUnsignedChar:recieveData[7]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recieveData[8]]intValue],recieveData[9],[[NSNumber numberWithUnsignedChar:recieveData[10]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recieveData[11]]intValue],recieveData[12],[[NSNumber numberWithUnsignedChar:recieveData[13]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recieveData[14]]intValue],recieveData[15],[[NSNumber numberWithUnsignedChar:recieveData[16]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recieveData[17]]intValue]];
                        _getdataBlock(BluetoothCodeTyppCorrent ,resultText);
                    };
                }else if (_isLineTestDataModel) {//直线测试结果数据
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr[3]]intValue]*16*16+[[NSNumber numberWithUnsignedChar:recievePtr[1]]intValue] + 4;
                        if (recievePtr1[2] == DeviceCmdTypeLineData){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    NSLog(@"count :%ld",_recieveData.length);
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
//                        [RGConnectDevice recieveLineTestResultData:_recieveData];
                        _getdataBlock(BluetoothCodeTyppCorrent,nil);
                    }
                }else if (_isEndTest) {//结束测试
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypesEndTest){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
                        BOOL resultB = [[NSNumber numberWithUnsignedChar:recievePtr1[4]] boolValue];
                        [self getRealDHOP];
                        _getdataBlock(resultB ? BluetoothCodeTypFailure : BluetoothCodeTyppCorrent ,nil);
                    }
                }else if (_isHistoryList) {//历史列表数据
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypesHistoryList){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
                        _getdataBlock(BluetoothCodeTyppCorrent,_recieveData);
                    }
                }else if (_isHistoryData) {//历史详情数据
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr[3]]intValue]*16*16 + [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypesHistoryData){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    NSLog(@"count 历史详情 :%ld",_recieveData.length);
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
//                        [RGConnectDevice recieveHistoricalTestResultData:_recieveData];
                        _getdataBlock(BluetoothCodeTyppCorrent,nil);
                    }
                }else if (_isClearCache) {//清除缓存
                    const unsigned char *recievePtr1 = [characteristic.value bytes];
                    if (_recieveData.length == 0){
                        historylenth= [[NSNumber numberWithUnsignedChar:recievePtr1[1]] integerValue] +4;
                        if (recievePtr1[2] == DeviceCmdTypesClearCache){
                            [_recieveData appendData:characteristic.value];
                        }
                    }else{
                        [_recieveData appendData:characteristic.value];
                    }
                    if (_recieveData.length == historylenth && _getdataBlock) {
                        [self successRecieve];
                        BOOL resultB = [[NSNumber numberWithUnsignedChar:recievePtr1[4]] boolValue];
                        _getdataBlock(resultB ? BluetoothCodeTypFailure : BluetoothCodeTyppCorrent ,nil);
                    }
                }
            }
        }
        @catch (NSException *exception) {
            
        }
    }
}
-(void)disconnect:(CBPeripheral *)peripheral{
    if (peripheral.state == CBPeripheralStateConnected) {
        [_centralManager cancelPeripheralConnection:peripheral];
    }
}
#pragma mark-获取实时DHOP
-(void)getRealDHOP{
    if (RGConnectDevice.isOnline) {
//        [BLEUtility readCharacteristic:RGConnectDevice.devicePeripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_DATA_UUID]];
//        [BLEUtility readCharacteristic:RGConnectDevice.devicePeripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_DATA_Test]];
//        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(getRealDHOP) object:nil];
//        [self performSelector:@selector(getRealDHOP) withObject:nil afterDelay:1];
    }
}
- (void)testTime:(NSData *)data
{
//    [_recieveData resetBytesInRange:NSMakeRange(0, _recieveData.length)];
//    [_recieveData setLength:0];
    if (RGConnectDevice.isOnline){
        [self successRecieve];
        [self performSelector:@selector(getdataFailed) withObject:nil afterDelay:2];
        [BLEUtility writeCharacteristic:RGConnectDevice.devicePeripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_WRITE_UUID] data:data];
    }else{
        _getdataBlock(BluetoothCodeTyppOffline,@"Blu_disconnect");
    }
}
- (void)getResult:(RGResultBlock)block index:(NSInteger)dex;
{
    [_recieveData resetBytesInRange:NSMakeRange(0, _recieveData.length)];
    [_recieveData setLength:0];
    self.getdataBlock = block;
    unsigned char sendStr[8];
    sendStr[0] = 0X0F;
    sendStr[1] = 0X04;
    sendStr[2] = DeviceCmdTypeLineData;
    sendStr[3] = 0X00;
    sendStr[4] = dex;
    sendStr[5] = 0X00;
    sendStr[6] = 0XFF;
    sendStr[7] = 0XFF;
    writeData = nil;
    writeData = [self CheckSum:sendStr length:8];
    if (RGConnectDevice.isOnline){
        [self successRecieve];
        [self performSelector:@selector(getdataFailed) withObject:nil afterDelay:3];
        _isLineTestModel = YES;
        [BLEUtility writeCharacteristic:RGConnectDevice.devicePeripheral sCBUUID:[CBUUID UUIDWithString:BT_SERVICE_UUID] cCBUUID:[CBUUID UUIDWithString:BT_WRITE_UUID] data:writeData];
    }else{
        _getdataBlock(BluetoothCodeTyppOffline,@"Blu_disconnect");
    }
}

#pragma mark - 获取设备的MAC地址，下发给蓝牙模块，模块纪录最近连接的设备
-(unsigned char *)macAddress{
    //Get MAC Address as unique identifier
    int mib[6];
    size_t len;
    char *buf;
    unsigned char *ptr;
    struct if_msghdr *ifm;
    struct sockaddr_dl *sdl;
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    if((mib[5] = if_nametoindex("en0")) == 0)
        return nil;  //Error:if_nametoindex error
    if(sysctl(mib, 6, NULL, &len, NULL, 0) < 0)
        return nil;  //Error:sysctl, take 1
    if((buf = malloc(len)) == NULL)
        return nil;  //Could not allocate memory. error!
    if(sysctl(mib, 6, buf, &len, NULL, 0) < 0){
        free(buf);
        return nil;  //Error:sysctl, take 2
    }
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outString;
    outString = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X", *ptr, *(ptr + 1), *(ptr + 2), *(ptr + 3), *(ptr + 4), *(ptr + 5)];
    
    NSLog(@"macaddress:%@",[outString uppercaseString]);
    
    free(buf);
    return ptr;
}

- (NSData *)CheckSum:(unsigned char *)recievePtr length:(NSUInteger)length
{
    NSInteger sum = 0;
    for (NSInteger i = 2; i < length - 3; i++) {
        sum += recievePtr[i];
    }
    sum += 0X01;
    recievePtr[length - 3] = sum % 0X100;
    writeData = [NSData dataWithBytes:recievePtr length:length];
    return writeData;
}

/**
 成功接收数据
 */
-(void)successRecieve
{
    [self initReceiveData];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(getdataFailed) object:nil];
}
- (void)initReceiveData
{
    _isTestModel = NO;
    _isTestDataModel = NO;
    _isLineTestModel = NO;
    _isLineTestDataModel = NO;
    _isEndTest = NO;
    _isHistoryList = NO;
    _isHistoryData = NO;
    _isClearCache = NO;
}
-(void)getdataFailed{
    NSLog(@"得到数据失败");
    [self initReceiveData];
    if (self.getdataBlock) {
        self.getdataBlock(BluetoothCodeTypSesion, @"overtime");
    }
}
@end


