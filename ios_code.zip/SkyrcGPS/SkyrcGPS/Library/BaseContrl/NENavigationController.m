//
//  NENavigationController.m
//  SwiftCam
//
//  Created by Billy Lee on 28/4/15.
//  Copyright (c) 2015 swiftcam.com. All rights reserved.
//

#import "NENavigationController.h"

@interface NENavigationController ()

@end

@implementation NENavigationController

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}


- (BOOL)shouldAutorotate {
    return self.topViewController.shouldAutorotate;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return [self.topViewController supportedInterfaceOrientations];
    
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return [self.topViewController preferredInterfaceOrientationForPresentation];
}

@end
