//
//  NEBaseViewController.m
//  SwiftCam
//
//  Created by billylee on 16/4/2015.
//  Copyright (c) 2015年 com.NEIL. All rights reserved.
//


#import "UINavigationBar+NEControl.h"
#import <MBProgressHUD/MBProgressHUD.h>

#import "UINavigationController+FDFullscreenPopGesture.h"

#import "NEBaseViewController.h"
@interface NEBaseViewController ()

@property (nonatomic, strong) MBProgressHUD *loadingHUD;
@property (nonatomic, strong) MBProgressHUD *progressHUD;
@property (nonatomic, assign) NSInteger naviControllerCount;

@end

@implementation NEBaseViewController{
}

+ (id)getDefaultController {
    return [[self alloc] initWithNibName:nil bundle:nil];
}

-(void)hideNavigation{
    self.fd_prefersNavigationBarHidden = YES;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resumeForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didChangeLanguage) name:kNELanguageChangeNotifactionKey object:nil];
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kNEColorBlack;
    self.navigationController.navigationBar.lineColor = kNEColorLine;
    self.naviControllerCount = self.navigationController.viewControllers.count;
    self.fd_interactivePopDisabled = YES;
    self.navigationController.navigationBar.ne_hiddenLine = NO;
    self.navigationController.navigationBar.barTintColor = kNEColorBlack;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    if (self.naviControllerCount==1) {
        if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.delegate = nil;
        }
    }
    self.tabBarItem.image = [self.tabBarItem.image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.tabBarItem.selectedImage = [self.tabBarItem.selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    NSMutableDictionary *textAtt = [NSMutableDictionary dictionary];
    textAtt[NSForegroundColorAttributeName] = kNEColorWhite;
    [self.tabBarItem setTitleTextAttributes:textAtt forState:UIControlStateNormal];
    textAtt[NSForegroundColorAttributeName] = kNEColorGreen;
    [self.tabBarItem setTitleTextAttributes:textAtt forState:UIControlStateSelected];
    [self didChangeLanguage];
}

- (void)viewWillAppear:(BOOL)animated{
    if (self.hiddenLen) {
        self.navigationController.navigationBar.ne_hiddenLine = YES;
    }
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.naviControllerCount==1 || self.popDisable) {
        if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = NO;
        }
    }
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (self.hiddenLen) {
        self.navigationController.navigationBar.ne_hiddenLine = NO;
    }
    if (self.naviControllerCount==1 || self.popDisable) {
        if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        }
    }
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}


- (void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kNELanguageChangeNotifactionKey object:nil];
}

#pragma mark - Notification
- (void)enterBackground{
    
}

- (void)resumeForeground{}

- (void)didChangeLanguage{}

#pragma mark - controllerStoryboardName

- (id)controllerStoryboardName:(NSString *)storyboardName identifier:(NSString *)identifier{
    if (!identifier) {
        return [[UIStoryboard storyboardWithName:storyboardName bundle:nil] instantiateInitialViewController];
    } else{
        return [[UIStoryboard storyboardWithName:storyboardName bundle:nil] instantiateViewControllerWithIdentifier:identifier];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
}

- (BOOL)prefersStatusBarHidden{
    return NO;
}


#pragma mark - show loading ..

- (void)showLoadingDialog:(BOOL)animated {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showLoadingDialog:NEString(@"loading") animated:animated];
    });
}

- (void)showLoadingDialogWithTitle:(NSString*)title {
    [self showLoadingDialog:title animated:NO];
}

- (void)showLoadingDialog:(NSString*)title animated:(BOOL)animated{
    [self showLoadingDialog:title message:nil animated:animated];
}

- (void)showLoadingDialog:(NSString*)title message:(NSString*)message {
    [self showLoadingDialog:title message:message animated:NO];
}

- (void)showLoadingDialog:(NSString*)title message:(NSString*)message animated:(BOOL)animated {
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    
    if (self.loadingHUD != nil) {
        [self.loadingHUD hideAnimated:NO];
        self.loadingHUD = nil;
    }
    
    self.loadingHUD = [MBProgressHUD showHUDAddedTo:self.navigationController ? self.navigationController.view : self.view animated:animated];
    self.loadingHUD.mode = MBProgressHUDModeIndeterminate;
    self.loadingHUD.bezelView.color = UIColorWithARGB(0.8f, 0.2f, 0.2f, 0.2f);
    
    self.loadingHUD.label.text = title;
    if (message.length > 0){
        self.loadingHUD.detailsLabel.text = message;
    }
}

- (void)dismissLoadingDialog:(BOOL)animated {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        }
    });
    
     dispatch_async(dispatch_get_main_queue(), ^{
        [self.loadingHUD hideAnimated:animated];
     });

}

- (void)showProgressDialog:(NSString*)title message:(NSString*)message progress:(float)progress{
    if (self.progressHUD == nil) {
        self.progressHUD = [MBProgressHUD showHUDAddedTo:self.navigationController ? self.navigationController.view : self.view animated:YES];
        self.progressHUD.mode = MBProgressHUDModeAnnularDeterminate;
        self.progressHUD.bezelView.color = UIColorWithARGB(0.8f, 0.2f, 0.2f, 0.2f);
    }
    
    self.progressHUD.label.text = title;
    if (message.length > 0) {
        self.progressHUD.detailsLabel.text = message;
    }
    self.progressHUD.progress = progress;
}

- (void)dismissProgressDialog:(BOOL)animated {
    [self.progressHUD hideAnimated:animated];
    if (self.progressHUD != nil) {
        [self.progressHUD hideAnimated:NO];
        self.progressHUD = nil;
    }
}

- (void)dismissAllHUD:(BOOL)animated {
    [MBProgressHUD hideHUDForView:self.navigationController ? self.navigationController.view : self.view animated:animated];
}

-(void)showLoadingHua:(NSString *)contents{
    if (self.loadingHUD != nil) {
        [self.loadingHUD hideAnimated:NO];
        self.loadingHUD = nil;
    }
    
    
    self.loadingHUD = [MBProgressHUD showHUDAddedTo:self.navigationController ? self.navigationController.view : self.view animated:YES];
    self.loadingHUD.mode = MBProgressHUDModeCustomView;
    self.loadingHUD.bezelView.color = UIColorWithARGB(0.8f, 0.2f, 0.2f, 0.2f);
    
    self.loadingHUD.label.text = contents;
    [self.loadingHUD hideAnimated:YES afterDelay:1.0];
    
}


- (void)showAlertOK:(NSString*)title message:(NSString*)message {
    [self showAlert:title message:message buttons:@[[AlertButton initWithText:NEString(@"ok") handler:nil]]];
}

- (void)showAlertOK:(NSString*)title message:(NSString*)message handler:(AlertButtonHandler)handler {
    [self showAlert:title message:message buttons:@[[AlertButton initWithText:NEString(@"ok") handler:handler]]];
}

- (void)showAlertOK:(NSString*)title message:(NSString*)message buttonText:(NSString*)button handler:(AlertButtonHandler)handler {
    [self showAlert:title message:message buttons:@[[AlertButton initWithText:button handler:handler]]];
}

-(void)showAlert:(NSString *)title
         message:(NSString *)message
   buttonHandler:(AlertButtonHandler)handler{
    AlertButton *ok = [AlertButton initWithText:NEString(@"ok") style:UIAlertActionStyleDefault handler:handler];
    AlertButton *cancel = [AlertButton initWithText:NEString(@"cancel") style:UIAlertActionStyleCancel handler:nil];
    [self showAlert:title message:message buttons:@[cancel, ok]];
}

- (void)showAlert:(NSString*)title
          message:(NSString*)message
       buttonText:(NSString*)buttonText
    buttonHandler:(AlertButtonHandler)handler
       cancelText:(NSString*)cancelText
    cancelHandler:(AlertButtonHandler)cancelHandler {
    
    UIAlertController *vc = [NEBaseViewController alertViewControllerWithTitle:title message:message buttonText:buttonText buttonHandler:handler cancelText:cancelText cancelHandler:cancelHandler];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)showAlert:(NSString*)title
       inputField:(AlertControllerHandler)inputHandler
       buttonText:(NSString*)buttonText
    buttonHandler:(AlertButtonHandler)handler
       cancelText:(NSString*)cancelText
    cancelHandler:(AlertButtonHandler)cancelHandler {
    
    UIAlertController *vc = [NEBaseViewController alertViewControllerWithTitle:title message:nil buttonText:buttonText buttonHandler:handler cancelText:cancelText cancelHandler:cancelHandler];
    inputHandler(vc);
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message buttons:(NSArray *)buttons {
    UIAlertController *alert = [NEBaseViewController alertViewControllerWithTitle:@"" message:message buttons:buttons];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showSheet:(NSString *)title message:(NSString *)message buttons:(NSArray*)buttons {
    UIAlertController *alert = [NEBaseViewController sheetViewControllerWithTitle:title message:message buttons:buttons];
    [self presentViewController:alert animated:YES completion:nil];
}


+ (UIAlertController*)alertViewControllerWithTitle:(NSString*)title
                                           message:(NSString*)message
                                        buttonText:(NSString*)buttonText
                                     buttonHandler:(AlertButtonHandler)handler
                                        cancelText:(NSString*)cancelText
                                     cancelHandler:(AlertButtonHandler)cancelHandler {
    
    AlertButton *ok = [AlertButton initWithText:buttonText style:UIAlertActionStyleDefault handler:handler];
    ok.titleColor = kNEColorRed;
    AlertButton *cancel = [AlertButton initWithText:cancelText style:UIAlertActionStyleCancel handler:cancelHandler];
    cancel.titleColor = UIColorWith256RGB(140, 140, 140);
    
    return [NEBaseViewController alertViewControllerWithTitle:title message:message buttons:@[ok, cancel]];
}

+ (UIAlertController*)alertViewControllerWithTitle:(NSString*)title message:(NSString*)message buttons:(NSArray*)buttons {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    for (AlertButton *button in buttons) {
        UIAlertAction *action = [UIAlertAction actionWithTitle:button.buttonString style:button.style handler:button.handler];
        if (button.titleColor) {
            [action setValue:button.titleColor forKey:@"_titleTextColor"];
        }
        [alert addAction:action];
    }
    return alert;
}

+ (UIAlertController*)sheetViewControllerWithTitle:(NSString*)title message:(NSString*)message buttons:(NSArray*)buttons {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleActionSheet];
    for (AlertButton *button in buttons) {
        [alert addAction:[UIAlertAction actionWithTitle:button.buttonString style:button.style handler:button.handler]];
    }
    return alert;
}
@end

@interface AlertButton()


@end

@implementation AlertButton

+ (id)initWithText:(NSString *)title handler:(AlertButtonHandler)handler {
    return [AlertButton initWithText:title style:UIAlertActionStyleDefault handler:handler];
}

+ (id)initWithText:(NSString*)title style:(UIAlertActionStyle)style handler:(AlertButtonHandler)handler {
    AlertButton *button = [[AlertButton alloc] init];
    button.buttonString = title;
    button.style = style;
    button.handler = handler;
    return button;
}

@end
