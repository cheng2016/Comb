//
//  ZFGenericChart.m
//  ZFChartView
//
//  Created by apple on 16/2/5.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ZFGenericChart.h"
#import "ZFAxisLine.h"
#import "ZFConst.h"
#import "RGSatelliteObject.h"

@interface ZFGenericChart()

/** 坐标轴 */
@property (nonatomic, strong) ZFAxisLine * axisLine;
/** x轴label高度 */
@property (nonatomic, assign) CGFloat xLineLabelHeight;

@end

@implementation ZFGenericChart

/**
 *  初始化默认变量
 */
- (void)commonInit{
    _yLineSectionCount = 5;
    _xLineLabelHeight = 30.f;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
        [self drawAxisLine];
    }
    
    return self;
}

#pragma mark - 坐标轴

/**
 *  画坐标轴
 */
- (void)drawAxisLine{
    self.axisLine = [[ZFAxisLine alloc] initWithFrame:self.bounds];
    [self addSubview:self.axisLine];
    [self.axisLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
}

/**
 *  设置x轴标题Label
 */
- (void)setXLineTitleLabel{
    for (NSInteger i = 0; i < self.modelarry.count; i++) {
        CGFloat xPos = self.axisLine.xLineStartXPos + XLineItemGapLength + (XLineItemWidth + XLineItemGapLength) * i;
        CGFloat yPos = self.axisLine.xLineStartYPos + 2;
        CGFloat width = XLineItemWidth;
        CGFloat height = _xLineLabelHeight;
        
        //label的中心点
        CGPoint label_center = CGPointMake(xPos + width * 0.5- XLineItemWidth/2, yPos + height * 0.5);
        UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, XLineItemWidth-2, XLineItemWidth-2)];
        RGSatelliteObject * satellite =self.modelarry[i];
        label.text = satellite.SatelliteId;
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor whiteColor];
        label.layer.cornerRadius = 5;
        label.clipsToBounds = YES;
        label.font = [UIFont systemFontOfSize:10.0f];
        label.numberOfLines = 0;
        label.textAlignment = NSTextAlignmentCenter;
        label.center = label_center;
        [self addSubview:label];
        //根据item个数,设置x轴长度
        if (i == self.modelarry.count - 1) {
            self.axisLine.xLineWidth = CGRectGetMaxX(label.frame) + XLineItemGapLength - self.axisLine.xLineStartXPos;
            self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.axisLine.xLineEndXPos, self.frame.size.height);
        }
    }
}

/**
 *  设置x轴valueLabel
 */
- (void)setXLineValueLabel{
    UIImageView  * imagview =[[UIImageView alloc]initWithFrame:CGRectMake(20,self.axisLine.xLineStartYPos + 5+ buttonheight/3, self.frame.size.width-40, buttonheight/3 *2-10)];
    imagview.image =[UIImage imageNamed:@"LOGO"];
    [self addSubview:imagview];
}


/**
 *  清除之前所有Label
 */
- (void)removeAllLabel{
    for (UIView * view in self.subviews) {
        if ([view isKindOfClass:[UILabel class]]||[view isKindOfClass:[UIImageView class]]) {
            [view removeFromSuperview];
        }
    }
}

#pragma mark - public method

/**
 *  重绘
 */
- (void)strokePath{
    self.axisLine.yLineSectionCount = _yLineSectionCount;
    
    [self removeAllLabel];
    [self.axisLine strokePath];
    [self setXLineValueLabel];
    [self setXLineTitleLabel];
}

#pragma mark - 重写setter,getter方法

/**
 *  获取坐标轴起点x值
 */
- (CGFloat)axisStartXPos{
    return self.axisLine.yLineStartXPos;
}

/**
 *  获取坐标轴起点Y值
 */
- (CGFloat)axisStartYPos{
    return self.axisLine.yLineStartYPos;
}

/**
 *  获取y轴最大上限值y值
 */
- (CGFloat)yLineMaxValueYPos{
    return self.axisLine.yLineEndYPos ;
}

/**
 *  获取y轴最大上限值与0值的高度
 */
- (CGFloat)yLineMaxValueHeight{
    return self.axisLine.yLineStartYPos - (self.axisLine.yLineEndYPos);
}

/** y轴结束Y位置(从数学坐标轴(0.0)(左下角)开始) */
- (CGFloat)yLineEndYPos{
    return self.axisLine.yLineEndYPos;
}

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
