//
//  ZFAxisLine.m
//  ZFChartView
//
//  Created by apple on 16/2/2.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ZFAxisLine.h"
#import "ZFConst.h"

@interface ZFAxisLine()

/** 分段线长度 */
@property (nonatomic, assign) CGFloat sectionLength;

@end

@implementation ZFAxisLine

/**
 *  初始化默认变量
 */
- (void)commonInit{
    _xLineWidth = self.frame.size.width - ZFAxisLineStartXPos - 20.f;
    _xLineHeight = 1.f;
    _yLineWidth = 0.f;
    _yLineHeight =  self.frame.size.height -topheight -buttonheight;
    
    _xLineStartXPos = ZFAxisLineStartXPos;
    _xLineStartYPos = self.frame.size.height -buttonheight;
    _xLineEndXPos = self.frame.size.width - 20;
    
    _yLineStartXPos = ZFAxisLineStartXPos;
    _yLineStartYPos = _xLineStartYPos;
    _yLineEndXPos = ZFAxisLineStartXPos;
    _yLineEndYPos = topheight;//上
    
    _sectionLength = self.frame.size.width - ZFAxisLineStartXPos - 20.f;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    
    return self;
}

#pragma mark - 坐标轴



/**
 *  x轴shapeLayer
 *
 *
 */
- (void )xAxisLineShapeLayer{
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    // 起点
    [linePath moveToPoint:CGPointMake(_xLineStartXPos, _xLineStartYPos)];
    // 其他点
    [linePath addLineToPoint:CGPointMake(_xLineEndXPos, _xLineStartYPos)];

    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    
    lineLayer.lineWidth = 1;
    
    lineLayer.strokeColor = kNEColorLine.CGColor;
    lineLayer.path = linePath.CGPath;
    lineLayer.fillColor = nil; // 默认为blackColor
    [self.layer addSublayer:lineLayer];
}

/**
 *  y轴shapeLayer
 *
 *
 */
- (void)yAxisLineShapeLayer:(NSInteger)index{
    UIBezierPath *linePath = [UIBezierPath bezierPath];
     CGFloat yStartPos = _yLineStartYPos - (_yLineHeight) / _yLineSectionCount * index;
    // 起点
    [linePath moveToPoint:CGPointMake(_yLineStartXPos, yStartPos)];
    // 其他点
    [linePath addLineToPoint:CGPointMake(_yLineStartXPos+_sectionLength, yStartPos)];
    
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    
    lineLayer.lineWidth = 1;
    lineLayer.strokeColor = kNEColorLine.CGColor;;
    lineLayer.path = linePath.CGPath;
    lineLayer.fillColor = nil; // 默认为blackColor
    [self.layer addSublayer:lineLayer];
    
}






/**
 *  清除之前所有subLayers
 */
- (void)removeAllSubLayers{
    NSArray * subLayers = [NSArray arrayWithArray:self.layer.sublayers];
    for (CALayer * layer in subLayers) {
        [layer removeAllAnimations];
        [layer removeFromSuperlayer];
    }
}

#pragma mark - public method

/**
 *  重绘
 */
- (void)strokePath{
    [self removeAllSubLayers];
    [self commonInit];
    [self xAxisLineShapeLayer];
    for (NSInteger i = 0; i <= _yLineSectionCount; i++) {
        [self yAxisLineShapeLayer:i];;
    }

}

#pragma mark - 重写setter,getter方法

- (void)setXLineWidth:(CGFloat)xLineWidth{
    if (xLineWidth < self.frame.size.width - ZFAxisLineStartXPos - 20.f) {
        _xLineWidth = self.frame.size.width - ZFAxisLineStartXPos - 20.f;
    }else{
        _xLineWidth = xLineWidth;
        _xLineEndXPos = _xLineStartXPos + _xLineWidth + 20.f;
    }
}

/**
 *  计算y轴分段高度的平均值
 */
- (CGFloat)yLineSectionHeightAverage{
    return ((_yLineHeight) / _yLineSectionCount);
}

@end

