//
//  ZFConst.h
//  ZFChartView
//
//  Created by apple on 16/3/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height



/**
 *  坐标轴起点x值
 */
extern CGFloat const ZFAxisLineStartXPos;

/**
 *  topheight
 */
extern CGFloat const topheight;

extern CGFloat const buttonheight; 

/**
 *  y轴label tag值
 */
extern NSInteger const YLineValueLabelTag;

/**
 *  x轴item宽度
 */
extern CGFloat const XLineItemWidth;

/**
 *  x轴item间隔
 */
extern CGFloat const XLineItemGapLength;





@interface ZFConst : NSObject

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
