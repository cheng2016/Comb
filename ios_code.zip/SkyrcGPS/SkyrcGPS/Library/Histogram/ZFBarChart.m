//
//  ZFBarChart.m
//  ZFChartView
//
//  Created by apple on 16/2/2.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ZFBarChart.h"
#import "ZFGenericChart.h"
#import "ZFBar.h"
#import "ZFConst.h"
#import "RGSatelliteObject.h"

@interface ZFBarChart()

/** 通用坐标轴图表 */
@property (nonatomic, strong) ZFGenericChart * genericChart;
/** 存储柱状条的数组 */
@property (nonatomic, strong) NSMutableArray * barArray;

@end

@implementation ZFBarChart

- (NSMutableArray *)barArray{
    if (!_barArray) {
        _barArray = [NSMutableArray array];
    }
    return _barArray;
}

/**
 *  初始化变量
 */
- (void)commonInit{
    _isShowValueOnChart = YES;
    _valueOnChartFontSize = 10.f;
    _isShadow = YES;
//    self.showsHorizontalScrollIndicator = NO;
//    self.delegate = self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self commonInit];
    [self drawGenericChart];
}



#pragma mark - 坐标轴

/**
 *  画坐标轴
 */
- (void)drawGenericChart{
    self.genericChart = [[ZFGenericChart alloc] initWithFrame:self.bounds];
    [self addSubview:self.genericChart];
    [self.genericChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
}
#pragma mark - 柱状条

/**
 *  画柱状条
 */
- (void)drawBar{
    [self removeAllBar];
    [self removeLabelOnChart];
    [self.barArray removeAllObjects];
    for (NSInteger i = 0; i < self.modelarry.count; i++) {
        CGFloat xPos = self.genericChart.axisStartXPos + XLineItemGapLength + (XLineItemWidth + XLineItemGapLength) * i;
        CGFloat yPos = self.genericChart.yLineMaxValueYPos;
        CGFloat width = XLineItemWidth;
        CGFloat height = self.genericChart.yLineMaxValueHeight;
        ZFBar * bar = [[ZFBar alloc] initWithFrame:CGRectMake(xPos, yPos, width, height)];
        //当前数值超过y轴显示上限时，柱状改为红色
        RGSatelliteObject * Satellite =self.modelarry[i];
        if (Satellite.signal / _yLineMaxValue <= 1) {
            bar.percent = Satellite.signal / _yLineMaxValue;
        }else{
            bar.percent = 1.f;
            bar.barBackgroundColor = [UIColor redColor];
        }
        bar.isShadow = _isShadow;
        [bar strokePath];
        [self.barArray addObject:bar];
        [self addSubview:bar];
    }
    _isShowValueOnChart ? [self showLabelOnChart] : nil;
}

/**
 *  显示bar上的label
 */
- (void)showLabelOnChart{
    for (NSInteger i = 0; i < self.barArray.count; i++) {
        ZFBar * bar = self.barArray[i];
        //label的中心点
        CGPoint label_center = CGPointMake(bar.center.x- XLineItemWidth/2, bar.endYPos);
        UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, XLineItemWidth,20)];
        RGSatelliteObject * Satellite =self.modelarry[i];
        label.text = [NSString stringWithFormat:@"%d",(int)Satellite.signal] ;
        label.font = [UIFont systemFontOfSize:_valueOnChartFontSize];
        label.numberOfLines = 0;
        label.textColor = [UIColor whiteColor];
        label.center = label_center;
        label.textAlignment = NSTextAlignmentCenter;
        [self addSubview:label];
    }
}

/**
 *  清除之前所有柱状条
 */
- (void)removeAllBar{
    for (UIView * view in self.subviews) {
        if ([view isKindOfClass:[ZFBar class]]) {
            [(ZFBar *)view removeFromSuperview];
        }
    }
}

/**
 *  清除圆环上的Label
 */
- (void)removeLabelOnChart{
    for (UIView * view in self.subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            [view removeFromSuperview];
        }
    }
}

#pragma mark - public method

/**
 *  重绘
 */
- (void)strokePath{
    [self.genericChart strokePath];
    [self drawBar];
}




-(void)setModelarry:(NSMutableArray *)modelarry{
    _modelarry = modelarry;
   self.genericChart.modelarry = _modelarry;
}

- (void)setYLineMaxValue:(float)yLineMaxValue{
    _yLineMaxValue = yLineMaxValue;
    self.genericChart.yLineMaxValue = _yLineMaxValue;
}

- (void)setYLineSectionCount:(NSInteger)yLineSectionCount{
    _yLineSectionCount = yLineSectionCount;
    self.genericChart.yLineSectionCount = _yLineSectionCount;
}


@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
