//
//  ZFBar.m
//  ZFChart
//
//  Created by apple on 16/1/26.
//  Copyright © 2016年 apple. All rights reserved.
//


#import "ZFBar.h"
#import "ZFConst.h"


@interface ZFBar()

/** bar宽度 */
@property (nonatomic, assign) CGFloat barWidth;
/** bar高度上限 */
@property (nonatomic, assign) CGFloat barHeightLimit;

@end

@implementation ZFBar

/**
 *  初始化默认变量
 */
- (void)commonInit{
    _barWidth = XLineItemWidth;
    _barHeightLimit = self.frame.size.height;
    _percent = 0;
    _isShadow = YES;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    
    return self;
}

/**
 *  CAShapeLayer
 *
 *
 */
- (void)shapeLayer{
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    CGFloat currentHeight = _barHeightLimit * self.percent;
    _endYPos = _barHeightLimit +5 - currentHeight;
    // 起点
    [linePath moveToPoint:CGPointMake(0, _barHeightLimit)];
    // 其他点
    [linePath addLineToPoint:CGPointMake(0, _barHeightLimit - currentHeight)];
    
    CAShapeLayer * layer = [CAShapeLayer layer];
    if (self.percent >=0.5) {
        _barBackgroundColor = [UIColor greenColor];
    }else if (self.percent >=0.25){
        _barBackgroundColor = [UIColor orangeColor];
    }else{
        _barBackgroundColor = [UIColor redColor];
    }
    layer.lineWidth = _barWidth;
    layer.strokeColor = _barBackgroundColor.CGColor;
    layer.fillColor = _barBackgroundColor.CGColor;
    layer.path = linePath.CGPath;
    
    if (_isShadow) {
        layer.shadowOpacity = 1.f;
        layer.shadowColor = [UIColor darkGrayColor].CGColor;
        layer.shadowOffset = CGSizeMake(2, 1);
    }
    
    [self.layer addSublayer:layer];
    
}



#pragma mark - public method

/**
 *  重绘
 */
- (void)strokePath{
    for (CALayer * layer in self.layer.sublayers) {
        [layer removeAllAnimations];
        [layer removeFromSuperlayer];
    }
    
    
    [self shapeLayer]; //画值来着
    
}

@end

