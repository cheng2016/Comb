//
//  UIButton+NEControl.h
//  RevogiHome
//
//  Created by NEIL on 2017/6/30.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "NEUtilityConstance.h"

#import <UIKit/UIKit.h>

typedef void(^NEButtonSelectedBlock)(id sender, BOOL neSelected);

//IB_DESIGNABLE

@interface UIButton (NEControl)

@property (nonatomic, assign) BOOL neSelected;

@property (nonatomic, assign) IBInspectable NSInteger neColorStyle;

@property (nonatomic, assign) IBInspectable NSInteger neTextSize;


@property (nonatomic, copy) NEButtonSelectedBlock didChangeNeSelected;

@end
