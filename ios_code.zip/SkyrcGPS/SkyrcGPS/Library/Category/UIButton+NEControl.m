//
//  UIButton+NEControl.m
//  RevogiHome
//
//  Created by NEIL on 2017/6/30.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "UIButton+NEControl.h"

#import "UIView+NEControl.h"

#import <objc/runtime.h>



@implementation UIButton (NEControl)

static char *ne_selectedKey = "ne_selectedKey";

static const char *didChangeNeSelectedKey = "didChangeNeSelectedKey";

+(void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class class = [self class];
        {
            SEL originalSelector = @selector(initWithCoder:);
            SEL swizzledSelector = @selector(neuibutton_initWithCoder:);
            
            Method originalMethod = class_getInstanceMethod(class, originalSelector);
            Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
            
            BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
            if (success) {
                class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
            } else {
                method_exchangeImplementations(originalMethod, swizzledMethod);
            }
        }
        
        {
            SEL originalSelector = @selector(layoutSubviews);
            SEL swizzledSelector = @selector(neuibutton_layoutSubviews);
            
            Method originalMethod = class_getInstanceMethod(class, originalSelector);
            Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
            
            BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
            if (success) {
                class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
            } else {
                method_exchangeImplementations(originalMethod, swizzledMethod);
            }
        }
        
    });
}

#pragma mark - runtime
- (instancetype)neuibutton_initWithCoder:(NSCoder *)aDecoder{
    id neSelf = [self neuibutton_initWithCoder:aDecoder];
    if (neSelf) {
        self.neSelected = NO;
        self.tintColor = kNEColorOrange;
        [self setTitleColor:kNEColorHighlighted forState:UIControlStateHighlighted];
    }
    return neSelf;
}

-(void)neuibutton_layoutSubviews{
    [self neuibutton_layoutSubviews];
    if ([self ne_circle]) {
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = self.frame.size.width / 2.0f;
    } else {
        if ([self ne_radius] > 0) {
            self.layer.masksToBounds = YES;
            self.layer.cornerRadius = self.ne_radius;
        }
    }
    
}

#pragma mark - property method

- (void)setNeColorStyle:(NSInteger)neColorStyle {
    objc_setAssociatedObject(self, @selector(neColorStyle), @(MAX(0, neColorStyle)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self inspectable];
}

- (NSInteger)neColorStyle {
    return MAX(0, [objc_getAssociatedObject(self, _cmd) integerValue]);
}

- (void)setNeTextSize:(NSInteger)neTextSize {
    objc_setAssociatedObject(self, @selector(neTextSize), @(MAX(0, neTextSize)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self inspectable];
}

- (NSInteger)neTextSize {
    return MAX(0, [objc_getAssociatedObject(self, _cmd) integerValue]);
}

- (void)setNeSelected:(BOOL)neSelected {
    objc_setAssociatedObject(self, ne_selectedKey, @(neSelected), OBJC_ASSOCIATION_ASSIGN);
    if (self.didChangeNeSelected) {
        self.didChangeNeSelected (self, neSelected);
    }
}

- (BOOL)neSelected {
    return [objc_getAssociatedObject(self, ne_selectedKey) boolValue];
}

- (void)setDidChangeNeSelected:(void (^)(id, BOOL))didChangeNeSelected {
    objc_setAssociatedObject(self, didChangeNeSelectedKey, didChangeNeSelected, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (NEButtonSelectedBlock)didChangeNeSelected {
    return objc_getAssociatedObject(self, didChangeNeSelectedKey);

}


#pragma mark - Inspectable

- (void)inspectable {
   // UIColor *_color = [NEUtility colorWithStyle:self.neColorStyle];
//    if (_color) {
//        [self setTitleColor:_color forState:UIControlStateNormal];
//        [self setTintColor:_color];
//    }
    
    if (self.neTextSize) {
        self.titleLabel.font  = [UIFont fontWithName:self.titleLabel.font.fontName size:self.neTextSize];
    }
}
@end
