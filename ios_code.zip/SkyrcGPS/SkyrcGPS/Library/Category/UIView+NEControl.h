//
//  UIView+NEControl.h
//  RevogiHome
//
//  Created by NEIL on 2017/7/1.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import <UIKit/UIKit.h>

//IB_DESIGNABLE

@interface UIView (NEControl)

@property (nonatomic, assign) IBInspectable BOOL ne_circle;

@property (nonatomic, assign) IBInspectable CGFloat ne_radius;

@property (nonatomic, assign) IBInspectable CGFloat ne_borderWidth;

@property (nonatomic, strong) IBInspectable UIColor *ne_borderColor;

@end
