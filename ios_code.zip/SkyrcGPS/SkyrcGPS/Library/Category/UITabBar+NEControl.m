//
//  UITabBar+NEControl.m
//  蓄电池测量仪
//
//  Created by Revogi on 2018/10/10.
//  Copyright © 2018年 Revogi. All rights reserved.
//

#import "UITabBar+NEControl.h"
#import <objc/runtime.h>

@implementation UITabBar (NEControl)


-(void)setLineColor:(UIColor *)lineColor
{
    self.shadowImage = [self imageWithColor:lineColor];
    objc_setAssociatedObject(self, @selector(lineColor), lineColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIColor *)lineColor {
    return objc_getAssociatedObject(self, _cmd);
}
- (UIImage *)imageWithColor:(UIColor *)color {
    // 描述矩形
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    // 开启位图上下文
    UIGraphicsBeginImageContext(rect.size);
    // 获取位图上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 使用color演示填充上下文
    CGContextSetFillColorWithColor(context, [color CGColor]);
    // 渲染上下文
    CGContextFillRect(context, rect);
    // 从上下文中获取图片
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    // 结束上下文
    UIGraphicsEndImageContext();
    
    return theImage;
}
@end
