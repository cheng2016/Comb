//
//  UINavigationBar+NEControl.h
//  RevogiHome
//
//  Created by NEIL on 2017/7/6.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import <UIKit/UIKit.h>
//IB_DESIGNABLE 
@interface UINavigationBar (NEControl)

@property (nonatomic, assign) IBInspectable NSInteger ne_style;

@property (nonatomic, assign) IBInspectable BOOL ne_hiddenLine;

@property (nonatomic, assign, readonly) UIImageView *ne_lineImageView;

@property (nonatomic, strong) UIColor *lineColor;

@end
