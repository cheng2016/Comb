//
//  UIView+NEControl.m
//  RevogiHome
//
//  Created by NEIL on 2017/7/1.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "UIView+NEControl.h"

#import <objc/runtime.h>


@implementation UIView (NEControl)

static char *ne_circleKey = "ne_circleKey";
static char *ne_radiusKey = "ne_radiusKey";
static char *ne_borderWidthKey = "ne_borderWidthKey";
static char *ne_borderColorKey = "ne_borderColorKey";

+(void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class class = [self class];
        {
            SEL originalSelector = @selector(didMoveToSuperview);
            SEL swizzledSelector = @selector(neuiview_didMoveToSuperview);
            
            Method originalMethod = class_getInstanceMethod(class, originalSelector);
            Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
            
            BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
            if (success) {
                class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
            } else {
                method_exchangeImplementations(originalMethod, swizzledMethod);
            }
        }
        {
            SEL originalSelector = @selector(layoutSubviews);
            SEL swizzledSelector = @selector(neuiview_layoutSubviews);
            
            Method originalMethod = class_getInstanceMethod(class, originalSelector);
            Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
            
            BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
            if (success) {
                class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
            } else {
                method_exchangeImplementations(originalMethod, swizzledMethod);
            }
        }
    });
}

#pragma mark - runtime
- (void)neuiview_didMoveToSuperview{
    [self neuiview_didMoveToSuperview];
}

-(void)neuiview_layoutSubviews{
    [self neuiview_layoutSubviews];
    if ([self ne_circle]) {
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = self.frame.size.width / 2.0f;
    } else {
        if ([self ne_radius] > 0) {
            self.layer.masksToBounds = YES;
            self.layer.cornerRadius = self.ne_radius;
        }
    }
}

#pragma mark - property method
- (void)setNe_circle:(BOOL)ne_circle {
    NSString *str = [NSString stringWithFormat:@"%i",ne_circle];
    objc_setAssociatedObject(self, ne_circleKey, str, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)ne_circle {
    return [objc_getAssociatedObject(self, ne_circleKey) boolValue];
}

- (void)setNe_radius:(CGFloat)ne_radius {
    objc_setAssociatedObject(self, ne_radiusKey, @(MAX(0, ne_radius)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGFloat)ne_radius {
    return MAX(0, [objc_getAssociatedObject(self, ne_radiusKey) floatValue]);
}

- (void)setNe_borderWidth:(CGFloat)ne_borderWidth {
    objc_setAssociatedObject(self, ne_borderWidthKey, @(MAX(0, ne_borderWidth)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    self.layer.borderWidth = self.ne_borderWidth;
    
}

- (CGFloat)ne_borderWidth {
    return MAX(0, [objc_getAssociatedObject(self, ne_borderWidthKey) floatValue]);
}

- (void)setNe_borderColor:(UIColor *)ne_borderColor {
    objc_setAssociatedObject(self, ne_borderColorKey, ne_borderColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    self.layer.borderColor = self.ne_borderColor.CGColor;
}

- (UIColor *)ne_borderColor {
    return objc_getAssociatedObject(self, ne_borderColorKey);
}
@end
