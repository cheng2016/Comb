//
//  UITabBar+NEControl.h
//  蓄电池测量仪
//
//  Created by Revogi on 2018/10/10.
//  Copyright © 2018年 Revogi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITabBar (NEControl)
@property (nonatomic, strong) UIColor *lineColor;
@end

NS_ASSUME_NONNULL_END
