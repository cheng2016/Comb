//
//  UINavigationBar+NEControl.m
//  RevogiHome
//
//  Created by NEIL on 2017/7/6.
//  Copyright © 2017年 NEIL. All rights reserved.
//

#import "UINavigationBar+NEControl.h"
#import <objc/runtime.h>

@implementation UINavigationBar (NEControl)
+(void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class class = [self class];
        
        SEL originalSelector = @selector(initWithCoder:);
        SEL swizzledSelector = @selector(netuinavigationbar_initWithCoder:);
        
        Method originalMethod = class_getInstanceMethod(class, originalSelector);
        Method swizzledMethod = class_getInstanceMethod(class, swizzledSelector);
        
        BOOL success = class_addMethod(class, originalSelector, method_getImplementation(swizzledMethod), method_getTypeEncoding(swizzledMethod));
        if (success) {
            class_replaceMethod(class, swizzledSelector, method_getImplementation(originalMethod), method_getTypeEncoding(originalMethod));
        } else {
            method_exchangeImplementations(originalMethod, swizzledMethod);
        }
    });
}

#pragma mark - runtime
-(instancetype)netuinavigationbar_initWithCoder:(NSCoder *)aDecoder{
    id neSelf = [self netuinavigationbar_initWithCoder:aDecoder];
    if (neSelf){
        [self inspectableTextColor];
    }
    return neSelf;
}

#pragma mark - property method
- (void)setNe_style:(NSInteger)ne_style{
    objc_setAssociatedObject(self, @selector(ne_style), @(MAX(0, ne_style)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self inspectableTextColor];
}

- (NSInteger)ne_style{
    return MAX(0, [objc_getAssociatedObject(self, _cmd) integerValue]);
}

- (void)setNe_hiddenLine:(BOOL)ne_hiddenLine{
    objc_setAssociatedObject(self, @selector(ne_hiddenLine), @(MAX(0, ne_hiddenLine)), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self inspectableLineImage];
}

- (BOOL)ne_hiddenLine {
    return [objc_getAssociatedObject(self, _cmd) boolValue];
}

- (UIImageView *)ne_lineImageView{
    return [self findHairlineImageViewUnder:self];
}

#pragma mark - Inspectable Style Color

- (void)inspectableTextColor {
    self.translucent = NO;
    self.barStyle = UIBarStyleDefault;
    self.barTintColor = kNEColorWhite;
    self.backgroundColor = kNEColorWhite;
    self.tintColor = kNEColorWhite;
    self.titleTextAttributes = @{NSForegroundColorAttributeName:kNEColorBlack,
                                 NSFontAttributeName:[UIFont fontWithName:kNECustomFontName size:18]};
    /*
    UIImage *image = [UIImage imageNamed:@"backBtn"];
    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.backIndicatorImage = image;
    self.backIndicatorTransitionMaskImage = image;
    UIBarButtonItem *buttonItem = [UIBarButtonItem appearanceWhenContainedIn:[self class], nil];
    UIOffset offset;
    offset.horizontal = - 500;
    offset.vertical =  - 500;
    [buttonItem setBackButtonTitlePositionAdjustment:offset forBarMetrics:UIBarMetricsDefault];
     */
}

//- (void)setNaviBack{
//    
//    UINavigationBar * navigationBar = [UINavigationBar appearance];
//    
//    //返回按钮的箭头颜色
//    
//    [navigationBar setTintColor:[UIColor colorWithRed:0.984 green:0.000 blue:0.235 alpha:1.000]];
//    
//    //设置返回样式图片
//    
//    UIImage *image = [UIImage imageNamed:@"bakeBtn"];
//    
//    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//    
//    navigationBar.backIndicatorImage = image;
//    
//    navigationBar.backIndicatorTransitionMaskImage = image;
//    
//    UIBarButtonItem *buttonItem = [UIBarButtonItem appearanceWhenContainedIn:[UINavigationBar class], nil];
//    
//    UIOffset offset;
//    
//    offset.horizontal = - 500;
//    
//    offset.vertical =  - 500;
//    
//    [buttonItem setBackButtonTitlePositionAdjustment:offset forBarMetrics:UIBarMetricsDefault];
//    
//}



#pragma mark - Inspectable Line Image

- (void)inspectableLineImage {
    if (self.ne_hiddenLine) {
//        self.ne_lineImageView.alpha = 0.0f;
        self.ne_lineImageView.hidden = YES;
    } else {
      //  self.ne_lineImageView.alpha = 1.0f;
        self.ne_lineImageView.hidden = NO;
    }
}

- (UIImageView *)findHairlineImageViewUnder:(UIView *)view{
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0){
        return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}

-(void)setLineColor:(UIColor *)lineColor
{
    self.shadowImage = [self imageWithColor:lineColor];
    objc_setAssociatedObject(self, @selector(lineColor), lineColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIColor *)lineColor {
    return objc_getAssociatedObject(self, _cmd);
}
- (UIImage *)imageWithColor:(UIColor *)color {
    // 描述矩形
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    // 开启位图上下文
    UIGraphicsBeginImageContext(rect.size);
    // 获取位图上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 使用color演示填充上下文
    CGContextSetFillColorWithColor(context, [color CGColor]);
    // 渲染上下文
    CGContextFillRect(context, rect);
    // 从上下文中获取图片
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    // 结束上下文
    UIGraphicsEndImageContext();
    
    return theImage;
}

@end
